var searchData=
[
  ['pbuttonnew_170',['pButtonNew',['../struct_controleur_tetris__t.html#afd72ce0024380450b6ed00997ea2e4aa',1,'ControleurTetris_t']]],
  ['pdownbutton_171',['pDownButton',['../struct_controleur_tetris__t.html#a9e93b86c43b007864728db5dce9387f6',1,'ControleurTetris_t']]],
  ['pscore_172',['pScore',['../struct_view_tetris__t.html#a648f9074dafafdd90a5d81faf51047b5',1,'ViewTetris_t']]]
];
