var searchData=
[
  ['score_174',['score',['../struct_model_tetris__t.html#a9dffb288f0f2281a0b9abbd8efaa5a18',1,'ModelTetris_t']]]
];
