var searchData=
[
  ['columns_159',['columns',['../struct_game_grid__t.html#a291416e9a8daa23be4958f548332b1f3',1,'GameGrid_t']]],
  ['currentpieceid_160',['currentPieceId',['../struct_model_tetris__t.html#a01080c49ed82439e7ac7495406ae0728',1,'ModelTetris_t']]]
];
