var searchData=
[
  ['move_5fpiece_5fleft_136',['move_piece_left',['../modele__tetris_8c.html#a55c71605bbde121a74a516bedbc847c2',1,'move_piece_left(GameGrid *grid, int pieceID):&#160;modele_tetris.c'],['../modele__tetris_8h.html#a55c71605bbde121a74a516bedbc847c2',1,'move_piece_left(GameGrid *grid, int pieceID):&#160;modele_tetris.c']]],
  ['move_5fpiece_5fright_137',['move_piece_right',['../modele__tetris_8c.html#a4315d7f5b8ed0395add91c9e6b33dcd9',1,'move_piece_right(GameGrid *grid, int pieceID):&#160;modele_tetris.c'],['../modele__tetris_8h.html#a4315d7f5b8ed0395add91c9e6b33dcd9',1,'move_piece_right(GameGrid *grid, int pieceID):&#160;modele_tetris.c']]]
];
