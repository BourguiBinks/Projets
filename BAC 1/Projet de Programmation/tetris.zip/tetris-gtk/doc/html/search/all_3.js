var searchData=
[
  ['find_5fpiece_26',['find_piece',['../modele__tetris_8c.html#ac7ea179362a08796e3dca5ff393af6b0',1,'find_piece(GameGrid *grid):&#160;modele_tetris.c'],['../modele__tetris_8h.html#ac7ea179362a08796e3dca5ff393af6b0',1,'find_piece(GameGrid *grid):&#160;modele_tetris.c']]],
  ['free_5fspawing_5fzone_27',['free_spawing_zone',['../modele__tetris_8c.html#a696e4465b013bd11e21350c6dbd03d81',1,'free_spawing_zone(GameGrid *grid):&#160;modele_tetris.c'],['../modele__tetris_8h.html#a340af7932f76edb97b76d2381e2f8926',1,'free_spawing_zone(GameGrid *grid):&#160;modele_tetris.c']]]
];
