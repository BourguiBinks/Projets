var searchData=
[
  ['pbuttonnew_60',['pButtonNew',['../struct_controleur_tetris__t.html#afd72ce0024380450b6ed00997ea2e4aa',1,'ControleurTetris_t']]],
  ['pdownbutton_61',['pDownButton',['../struct_controleur_tetris__t.html#a9e93b86c43b007864728db5dce9387f6',1,'ControleurTetris_t']]],
  ['place_5fblock_62',['place_block',['../modele__tetris_8c.html#a0d45b4e8df62256fc0ee8bc993e49fcd',1,'place_block(GameGrid *grid):&#160;modele_tetris.c'],['../modele__tetris_8h.html#ab74dbb7bee2257f34687baae01fb5361',1,'place_block(GameGrid *grid):&#160;modele_tetris.c'],['../vue__tetris_8h.html#ab74dbb7bee2257f34687baae01fb5361',1,'place_block(GameGrid *grid):&#160;modele_tetris.c']]],
  ['place_5fstick_63',['place_stick',['../modele__tetris_8c.html#a14ccd663e81e76e9861d43b0710516cf',1,'place_stick(GameGrid *grid):&#160;modele_tetris.c'],['../modele__tetris_8h.html#a59303c9a9e8433fd5d4550dcbe8f5144',1,'place_stick(GameGrid *grid):&#160;modele_tetris.c'],['../vue__tetris_8h.html#a59303c9a9e8433fd5d4550dcbe8f5144',1,'place_stick(GameGrid *grid):&#160;modele_tetris.c']]],
  ['place_5fte_64',['place_te',['../modele__tetris_8c.html#a9799d58b4e598f53192421b694b6ce1b',1,'place_te(GameGrid *grid):&#160;modele_tetris.c'],['../modele__tetris_8h.html#a8255eeb9367ae4a1cb8d55f9aa19fdc0',1,'place_te(GameGrid *grid):&#160;modele_tetris.c'],['../vue__tetris_8h.html#a8255eeb9367ae4a1cb8d55f9aa19fdc0',1,'place_te(GameGrid *grid):&#160;modele_tetris.c']]],
  ['print_5flist_65',['print_list',['../modele__tetris_8c.html#a988e50cf56b95b53fea079e439947081',1,'print_list(Cell *head):&#160;modele_tetris.c'],['../modele__tetris_8h.html#a988e50cf56b95b53fea079e439947081',1,'print_list(Cell *head):&#160;modele_tetris.c']]],
  ['pscore_66',['pScore',['../struct_view_tetris__t.html#a648f9074dafafdd90a5d81faf51047b5',1,'ViewTetris_t']]],
  ['put_5fpiece_5fdown_67',['put_piece_down',['../modele__tetris_8c.html#a6ff23f0e46d30813bff55c404f4dcfeb',1,'put_piece_down(GameGrid *grid, int id):&#160;modele_tetris.c'],['../modele__tetris_8h.html#a1215f07d21fea1ff1f6899eea5d919cb',1,'put_piece_down(GameGrid *grid, int id):&#160;modele_tetris.c']]]
];
