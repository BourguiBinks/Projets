var searchData=
[
  ['model_168',['model',['../struct_controleur_tetris__t.html#a6ff8b8b6051d54bd24d5f3a9988da773',1,'ControleurTetris_t::model()'],['../struct_view_tetris__t.html#a6ff8b8b6051d54bd24d5f3a9988da773',1,'ViewTetris_t::model()']]]
];
