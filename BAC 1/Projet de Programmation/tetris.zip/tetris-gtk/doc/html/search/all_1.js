var searchData=
[
  ['calculate_5fscore_2',['calculate_score',['../modele__tetris_8c.html#a8e61ecf0a13747e91408b02bdacbd447',1,'calculate_score(ModelTetris *model, unsigned int rows):&#160;modele_tetris.c'],['../modele__tetris_8h.html#a8e61ecf0a13747e91408b02bdacbd447',1,'calculate_score(ModelTetris *model, unsigned int rows):&#160;modele_tetris.c']]],
  ['cell_3',['Cell',['../modele__tetris_8h.html#aba53f1eed86d6c73c4882f93aab2e0cd',1,'modele_tetris.h']]],
  ['cell_5ft_4',['Cell_t',['../struct_cell__t.html',1,'']]],
  ['clear_5fgrid_5',['clear_grid',['../modele__tetris_8c.html#a329aef852208dca7d07a3d43553545af',1,'clear_grid(GameGrid *grid):&#160;modele_tetris.c'],['../modele__tetris_8h.html#a329aef852208dca7d07a3d43553545af',1,'clear_grid(GameGrid *grid):&#160;modele_tetris.c']]],
  ['columns_6',['columns',['../struct_game_grid__t.html#a291416e9a8daa23be4958f548332b1f3',1,'GameGrid_t']]],
  ['complete_5frow_7',['complete_row',['../modele__tetris_8c.html#aa2758cce0409550f3405421df60e7d3a',1,'complete_row(GameGrid *grid):&#160;modele_tetris.c'],['../modele__tetris_8h.html#aea7bed3a1bed9aea54aa688463394fab',1,'complete_row(GameGrid *grid):&#160;modele_tetris.c']]],
  ['controleur_5ftetris_2ec_8',['controleur_tetris.c',['../controleur__tetris_8c.html',1,'']]],
  ['controleur_5ftetris_2eh_9',['controleur_tetris.h',['../controleur__tetris_8h.html',1,'']]],
  ['controleurtetris_10',['ControleurTetris',['../controleur__tetris_8h.html#a5de2a3db65aaecb407ab4009df0e1ab2',1,'controleur_tetris.h']]],
  ['controleurtetris_5ft_11',['ControleurTetris_t',['../struct_controleur_tetris__t.html',1,'']]],
  ['create_5fcontroleur_5ftetris_12',['create_controleur_tetris',['../controleur__tetris_8c.html#a04d94d5246bc0c309342ec046ddb8334',1,'create_controleur_tetris(ModelTetris *model, ViewTetris *view):&#160;controleur_tetris.c'],['../controleur__tetris_8h.html#a6b0da97a3e1947536e537d7e4e35af19',1,'create_controleur_tetris(ModelTetris *model, ViewTetris *view):&#160;controleur_tetris.c']]],
  ['create_5fmenu_5fzone_5f1_13',['create_menu_zone_1',['../vue__tetris_8c.html#a3d4a10f31e6a8cc17d6333e852f6f9db',1,'create_menu_zone_1(GtkWidget *window):&#160;vue_tetris.c'],['../vue__tetris_8h.html#a0679321554c71219dae600ed6729030a',1,'create_menu_zone_1(GtkWidget *window):&#160;vue_tetris.c']]],
  ['create_5fmodel_5ftetris_14',['create_model_tetris',['../modele__tetris_8c.html#ab7bdd1b38c0359683060b7d84e96644c',1,'create_model_tetris():&#160;modele_tetris.c'],['../modele__tetris_8h.html#a77134fdaa24062aff91d4394c07d96d1',1,'create_model_tetris():&#160;modele_tetris.c']]],
  ['currentpieceid_15',['currentPieceId',['../struct_model_tetris__t.html#a01080c49ed82439e7ac7495406ae0728',1,'ModelTetris_t']]]
];
