/**
 * \file controleur_tetris.h
 * \author Alexandre Bourguignon
 * \author Julien Peffer
 * \brief Gestion d'une calculatrice via une approche MVC. Ce fichier contient les déclarations de types et les prototypes
 * des fonctions pour le controleur du jeu tetris
 * \version 0.1
 * \date 2023-04-26
 * INFO0030 : Projet 4
 * 
 * 
 */

#ifndef __CONTROLEUR_TETRIS__
#define __CONTROLEUR_TETRIS__

#define MAX_PLAYERS 10

/**
 * \brief Implémentation du controleur pour le tetris.
 */
typedef struct ControleurTetris_t{
    ModelTetris *model; /*!< modèle du tetris */
    ViewTetris *view; /*!< vue du tetris */
    GtkWidget *pDownButton; /*!< le bouton flèche du bas */
    GtkWidget *pLeftButton;
    GtkWidget *pRightButton;
    GtkWidget *pButtonNew; /*!< le bouton nouveau */
}ControleurTetris;

typedef struct {
    char name[20];
    int score;
}Player;

void read_players(Player players[MAX_PLAYERS], int *num_players);

void add_player(Player players[MAX_PLAYERS], int *num_players, const char *name, int score);

void write_players(const Player players[MAX_PLAYERS], int num_players);

void add_player_to_file(const char *name, int score);

char* read_scores_from_file();


gboolean on_key_pressed(GtkWidget *widget, GdkEventKey *event, gpointer user_data);

/**
 * \fn ControleurTetris *create_controleur_tetris(ModelTetris *model, ViewTetris *view)
 * \brief Crée un controleur pour le tetris
 *
 * \param model une variable contenant l'adresse en mémoire qui pointe vers une instance de la structure ModelTetris.
 * \param view une variable contenant l'adresse en mémoire qui pointe vers une instance de la structure ViewTetris.
 *
 * \return ControleurCalculatrice *, un pointeur vers une instance de la structure ControleurCalculatrice.
 *         NULL en cas d'erreur 
 */
ControleurTetris *create_controleur_tetris(ModelTetris *model, ViewTetris *view);

/**
 * \fn void destroy_controleur_tetris(ControleurTetris *controleur)
 * \brief Détruit un controleur pour le tetris
 *
 * \param controleur, une variable contenant l'adresse en mémoire qui pointe vers une instance de la structure ControleurTetris.
 */
void destroy_controleur_tetris(ControleurTetris *controleur);



// void in_game(ControleurTetris *controleur);


/**
 * \fn ControleurTetris *set_down_button(ControleurTetris *controleur, GtkWidget *pDownButton)
 * \brief Accesseur en écriture pour le bouton bas.
 *
 * \param controleur une variable contenant l'adresse en mémoire qui pointe vers une instance de la structure ControleurTetris.
 * \param pDownButton une variable contenant le widget à insérer dans le champs spécifié.
 *
 * \return ControleurCalculatrice *, un pointeur vers une instance de la structure ControleurCalculatrice.        
 */
ControleurTetris *set_down_button(ControleurTetris *controleur, GtkWidget *pDownButton);

/**
 * \fn ControleurTetris *set_new_button(ControleurTetris *controleur, GtkWidget *pButtonNew)
 * \brief Accesseur en écriture pour le bouton nouveau.
 *
 * \param controleur une variable contenant l'adresse en mémoire qui pointe vers une instance de la structure ControleurTetris.
 * \param pButtonNew une variable contenant le widget à insérer dans le champs spécifié.
 *
 * \return ControleurCalculatrice *, un pointeur vers une instance de la structure ControleurCalculatrice.        
 */
ControleurTetris *set_new_button(ControleurTetris *controleur, GtkWidget *pButtonNew);

/**
 * \fn void on_button_new_clicked(GtkWidget *pButtonNew, gpointer data)
 * \brief Signal pour le bouton nouveau du tetris.
 *
 * \param pButtonNew le widget en cause.
 * \param data un pointeur vers le controleur.
 */
void on_button_new_clicked(GtkWidget *pButtonNew, gpointer data);

/**
 * \fn void on_button_down_clicked(GtkWidget *pDownButton, gpointer data)
 * \brief Signal pour le bouton bas du tetris.
 *
 * \param pDownButton le widget en cause.
 * \param data un pointeur vers le controleur.
 */
void on_button_down_clicked(GtkWidget *pDownButton, gpointer data);

/**
 * \fn void on_button_end_clicked(GtkWidget *pEndButton, gpointer data)
 * \brief Signal pour le bouton fin du tetris.
 *
 * \param pEndButton le widget en cause.
 * \param data un pointeur vers le controleur.
 */
void on_button_end_clicked(GtkWidget *pEndButton, gpointer data);

/**
 * \fn void on_button_right_clicked(GtkWidget *pRightButton, gpointer data)
 * \brief Signal pour le bouton droit du tetris.
 *
 * \param pRightButton le widget en cause.
 * \param data un pointeur vers le controleur.
 */
void on_button_right_clicked(GtkWidget *pRightButton, gpointer data);

/**
 * \fn void on_button_left_clicked(GtkWidget *pLeftButton, gpointer data)
 * \brief Signal pour le bouton gauche du tetris.
 *
 * \param pLeftButton le widget en cause.
 * \param data un pointeur vers le controleur.
 */
void on_button_left_clicked(GtkWidget *pLeftButton, gpointer data);

#endif 
