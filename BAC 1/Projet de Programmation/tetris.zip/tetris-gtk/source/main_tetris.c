/**
 * @file main_tetris.c
 * @author Alexandre Bourguignon
 * @author Julien Peffer
 * @brief Ce fichier contient la fonction main qui permet de tester le jeu tetris
 * @version 0.1
 * @date 2023-04-26
 * INFO0030 : Projet 4
 *
 */

#include <stdlib.h>
#include <gtk/gtk.h>
#include <string.h>
#include <gdk/gdkkeysyms.h>
#include "assert.h"

#include "modele_tetris.h"
#include "controleur_tetris.h"
#include "vue_tetris.h"


/**
 * \fn static void destroy_window(GtkWidget *pF, gpointer data)
 * \brief Détruit la fenêtre TOPLEVEL
 *
 * \param pF le widget en cause.
 * \param data un pointeur sur void.
 */
static void destroy_window(GtkWidget *pF, gpointer data){
  gtk_main_quit();
} // fin detruire_fenetre()

/**
 * \fn static GtkWidget *create_window()
 * \brief Crée la fenêtre TOPLEVEL
 */
static GtkWidget *create_window(){
  GtkWidget *pFenetre = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title(GTK_WINDOW(pFenetre), "Tetris GTK");
  gtk_window_set_default_size(GTK_WINDOW(pFenetre), 600, 750);
  gtk_window_set_position(GTK_WINDOW(pFenetre), GTK_WIN_POS_CENTER);
  g_signal_connect(G_OBJECT(pFenetre), "destroy", G_CALLBACK(destroy_window), NULL);

  return pFenetre;
} // fin create_window()

/**
 * \fn static gboolean realize_evt_reaction(GtkWidget *widget, gpointer data)
 * \brief Gere l'événement realisation sur le widget spécifié
 *
 * \param widget le widget en cause.
 * \param data un pointeur sur void.
 *
 * \return TRUE
*/
static gboolean realize_evt_reaction(GtkWidget *widget, gpointer data){
  gtk_widget_queue_draw(widget);
  return TRUE;
}// fin realize_evt_reaction()

/**
 * \fn static gboolean expose_evt_reaction(GtkWidget *widget, GdkEventExpose *event, gpointer data)
 * \brief Gere l'événement expose sur le widget spécifié
 *
 * \param widget le widget en cause.
 * \param event pointeur vers une structure GdkEventExpose.
 * \param data un pointeur sur void.
 *
 * \return TRUE
*/
static gboolean expose_evt_reaction(GtkWidget *widget, GdkEventExpose *event, gpointer data){
  cairo_t* cr = gdk_cairo_create(widget->window);
  //Fond gris (à remettre en blanc éventuellement)
  cairo_set_source_rgb(cr, 0.5, 0.5, 0.5);
  cairo_paint(cr);
  cairo_stroke(cr);
  draw_horizontal_line(widget);
  cairo_destroy(cr);

  return TRUE;
}// fin expose_evt_reaction()

/**
 * \fn static GtkWidget *create_drawing_area()
 * \brief Crée la zone de dessin
 *
 * \return drawingArea
 */
static GtkWidget *create_drawing_area() {
    GtkWidget *drawingArea = gtk_drawing_area_new();
    int taille_carre = 16;
    int largeur_grille = 10;
    int hauteur_grille = 20;
    int width = taille_carre * (largeur_grille + 4);
    int height = taille_carre * (hauteur_grille + 7);
    gtk_widget_set_size_request(drawingArea, 330, 509);

    return drawingArea;
}// fin create_drawing_area()

int main(int argc, char **argv){
  srand(time(NULL));

  // creation d'un modele pour le tetris
  ModelTetris *model = create_model_tetris();
  if(model == NULL){
    printf("Erreur d'allocation de mémoire \n");
    return EXIT_FAILURE;
  }
  // creation d'une vue pour le tetris
  ViewTetris *view = create_view_tetris(model);
  if (view == NULL){
    printf("Impossible d'allouer de la mémoire\n");
    return EXIT_FAILURE;
  }
  // creation d'un controleur pour le tetris
  ControleurTetris *controleur = create_controleur_tetris(model, view);
  if(controleur == NULL){
    printf("Impossible d'allouer de la mémoire \n");
    return EXIT_FAILURE;
  }

  gtk_init(&argc, &argv);

  GtkWidget *window = create_window();
  set_window(view, window);

  // Ajout d'une icône à la fenêtre
  GError *error = NULL;
  GdkPixbuf *icon = gdk_pixbuf_new_from_file("tetris_logo", &error);

  if(error != NULL){
    g_warning("Impossible de charger l'icône : %s", error->message);
    g_error_free(error);
  }
  else{
    gtk_window_set_icon(GTK_WINDOW(window), icon);
    g_object_unref(icon);
  }

  // Création d'une table
  GtkWidget *table = gtk_table_new(7, 3, TRUE);
  gtk_container_add(GTK_CONTAINER(window), table);

  GtkWidget *menuBar = create_menu_zone_1(window);
  gtk_table_attach(GTK_TABLE(table), menuBar, 0, 4, 0, 1, GTK_FILL, GTK_SHRINK, 0, 0);

  // Création du bouton "Nouveau"
  GtkWidget *newButton = gtk_button_new_with_label("Nouveau");
  gtk_table_attach(GTK_TABLE(table), newButton, 3, 4, 1, 2, GTK_EXPAND, GTK_EXPAND, 0, 0);
  gtk_widget_set_size_request(newButton, 100, 50);
  g_signal_connect(G_OBJECT(newButton), "clicked", G_CALLBACK(on_button_new_clicked), controleur); 
  set_new_button(controleur, newButton);

  // Création du bouton "Fin"
  GtkWidget *endButton = gtk_button_new_with_label("Fin");
  gtk_table_attach(GTK_TABLE(table), endButton, 3, 4, 2, 3, GTK_EXPAND, GTK_EXPAND, 0, 0);
  gtk_widget_set_size_request(endButton, 100, 50);
  g_signal_connect(G_OBJECT(endButton), "clicked", G_CALLBACK(on_button_end_clicked), controleur);

  // Création du label "Score"
  GtkWidget *scoreLabel = gtk_label_new("Score :");
  // scoreLabel = get_score_in_view(view);
  set_score_in_view(view, scoreLabel);
  gtk_table_attach(GTK_TABLE(table), scoreLabel, 3, 4, 4, 5, GTK_EXPAND, GTK_EXPAND, 0, 0);
  gtk_widget_set_size_request(scoreLabel, 90, 40);

  //Création du label "Délai"
  GtkWidget *delayLabel = gtk_label_new("Délai :");
  set_value_delay(view, delayLabel);
  gtk_table_attach(GTK_TABLE(table), delayLabel, 3, 4, 5, 6, GTK_EXPAND, GTK_EXPAND, 0, 0);
  gtk_widget_set_size_request(delayLabel, 70, 40);

  // Création du bouton gauche
  GtkWidget *leftButton = gtk_button_new();
  GtkWidget *leftArrow = gtk_arrow_new(GTK_ARROW_LEFT, GTK_SHADOW_OUT);
  controleur->pLeftButton = leftButton;
  GtkAccelGroup *accelGroup = gtk_accel_group_new();
  gtk_widget_add_accelerator(leftButton, "clicked", accelGroup, GDK_Left, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
  gtk_window_add_accel_group(GTK_WINDOW(window), accelGroup);
  gtk_container_add(GTK_CONTAINER(leftButton), leftArrow);
  gtk_table_attach(GTK_TABLE(table), leftButton, 0, 1, 7, 8, GTK_EXPAND, GTK_EXPAND, 0, 0);
  gtk_widget_set_size_request(leftButton, 100, 50);
  g_signal_connect(G_OBJECT(leftButton), "clicked", G_CALLBACK(on_button_left_clicked), controleur);


  // Création du bouton bas
  GtkWidget *downButton = gtk_button_new();
  GtkWidget *downArrow = gtk_arrow_new(GTK_ARROW_DOWN, GTK_SHADOW_OUT);
  GtkAccelGroup *accelGroup2 = gtk_accel_group_new();
  gtk_widget_add_accelerator(downButton, "clicked", accelGroup2, GDK_Down, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
  gtk_container_add(GTK_CONTAINER(downButton), downArrow);
  gtk_table_attach(GTK_TABLE(table), downButton, 1, 2, 7, 8, GTK_EXPAND, GTK_EXPAND, 0, 0);
  gtk_widget_set_size_request(downButton, 100, 50);
  g_signal_connect(G_OBJECT(downButton), "clicked", G_CALLBACK(on_button_down_clicked), controleur);
  set_down_button(controleur, downButton);

  // Création du bouton droite
  GtkWidget *rightButton = gtk_button_new();
  GtkWidget *rightArrow = gtk_arrow_new(GTK_ARROW_RIGHT, GTK_SHADOW_OUT);
  controleur->pRightButton = rightButton;
  GtkAccelGroup *accelGroup3 = gtk_accel_group_new();
  gtk_widget_add_accelerator(rightButton, "clicked", accelGroup3, GDK_Right, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
  gtk_container_add(GTK_CONTAINER(rightButton), rightArrow);
  gtk_table_attach(GTK_TABLE(table), rightButton, 2, 3, 7, 8, GTK_EXPAND, GTK_EXPAND, 0, 0);
  gtk_widget_set_size_request(rightButton, 100, 50);
  g_signal_connect(G_OBJECT(rightButton), "clicked", G_CALLBACK(on_button_right_clicked), controleur);

  // Création de la zone de dessin
  GtkWidget *drawingArea = create_drawing_area();
  gtk_table_attach(GTK_TABLE(table), drawingArea, 0, 3, 1, 7, GTK_FILL, GTK_FILL | GTK_EXPAND, 43, 0);
  g_signal_connect(GTK_OBJECT(drawingArea), "realize", G_CALLBACK(realize_evt_reaction), view);
  g_signal_connect(GTK_OBJECT(drawingArea), "expose_event", G_CALLBACK(expose_evt_reaction), view);
  set_drawingArea(view, drawingArea);

  g_signal_connect(G_OBJECT(window), "key-press-event", G_CALLBACK(on_key_pressed), controleur);
  gtk_widget_show_all(window);

  gtk_main();

  destroy_model_tetris(model);
  destroy_view_tetris(view);
  destroy_controleur_tetris(controleur);
  return EXIT_SUCCESS;
}
