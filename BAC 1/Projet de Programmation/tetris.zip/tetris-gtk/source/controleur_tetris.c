/**
 * @file controleur_tetris.c
 * @author Alexandre Bourguignon
 * @author Julien Peffer
 * @brief Ce fichier contient le controleur du jeu tetris
 * @version 0.1
 * @date 2023-04-26
 * INFO0030 : Projet 4
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <stdbool.h>
#include <gtk/gtk.h>
#include <time.h>
#include <unistd.h>
#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>

#include "modele_tetris.h"
#include "vue_tetris.h"
#include "controleur_tetris.h"

static unsigned int delayCounter = 6;
static unsigned int controlerCount = 0;
static gboolean isButtonDown = FALSE;
static gboolean isButtonNew = FALSE;
static unsigned int piecePlaced = 0;

/**
 * \fn static gboolean expose_evt_reaction(GtkWidget *widget, GdkEventExpose *event, gpointer data)
 * \brief Gere l'événement expose sur le widget spécifié
 *
 * \param widget le widget en cause.
 * \param event pointeur vers une structure GdkEventExpose.
 * \param data un pointeur sur void.
 *
 * \return TRUE
*/
static gboolean expose_event_reaction(GtkWidget *widget, GdkEventExpose *event, gpointer data);

/**
 * \fn static gint tic(gpointer data)
 * \brief Gère l'enclenchement d'un timer
 *
 * \param data le widget en cause.
 * 
 * \return 0
 */
static gint tic(gpointer data);

/**
 * \fn static void end_game(ControleurTetris *controleur)
 * \brief Gère la fin d'une partie
 *
 * \param controleur, une variable contenant l'adresse en mémoire qui pointe vers une instance de la structure ControleurTetris.
 */
static void end_game(ControleurTetris *controleur);


void read_players(Player players[MAX_PLAYERS], int *num_players) {
    FILE *file = fopen("scores.txt", "r");
    if (file == NULL) {
        *num_players = 0;
        return;
    }

    *num_players = 0;
    while ((*num_players) < MAX_PLAYERS && fscanf(file, "%s %d", players[*num_players].name, &players[*num_players].score) == 2) {
        (*num_players)++;
    }

    fclose(file);
}

void add_player(Player players[MAX_PLAYERS], int *num_players, const char *name, int score) {
    // Vérifier si le nom existe déjà
    for (int i = 0; i < *num_players; i++) {
        if (strcmp(players[i].name, name) == 0) {
            // Mettre à jour le score si le nouveau score est supérieur
            if (score > players[i].score) {
                players[i].score = score;
            }
            return;  // Quitter la fonction, le joueur existe déjà
        }
    }

    // Le nom n'existe pas, ajouter un nouveau joueur
    Player new_player;
    strncpy(new_player.name, name, sizeof(new_player.name));
    new_player.name[sizeof(new_player.name) - 1] = '\0';
    new_player.score = score;

    // Trouver l'indice où insérer le nouveau joueur en maintenant le tableau trié
    int index = *num_players;
    while (index > 0 && new_player.score > players[index - 1].score) {
        players[index] = players[index - 1];
        index--;
    }

    // Insérer le nouveau joueur
    players[index] = new_player;

    // Mettre à jour le nombre de joueurs (limiter à MAX_PLAYERS)
    (*num_players)++;
    if (*num_players > MAX_PLAYERS) {
        (*num_players) = MAX_PLAYERS;
    }
}


void write_players(const Player players[MAX_PLAYERS], int num_players) {
    FILE *file = fopen("scores.txt", "w");
    if (file == NULL) {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return;
    }

    for (int i = 0; i < num_players; i++) {
        fprintf(file, "%s %d\n", players[i].name, players[i].score);
    }

    fclose(file);
}

void add_player_to_file(const char *name, int score) {
    Player players[MAX_PLAYERS];
    int num_players;

    // Lire les joueurs existants
    read_players(players, &num_players);

    add_player(players, &num_players, name, score);

    // Écrire les joueurs dans le fichier
    write_players(players, num_players);
}

char* read_scores_from_file() {
    FILE* file = fopen("scores.txt", "r");
    if (file == NULL) {
        fprintf(stderr, "Erreur lors de l'ouverture du fichier scores.txt\n");
        return NULL;
    }

    // Lire le contenu du fichier
    char* scores = malloc(1000 * sizeof(char));  // Assurez-vous de choisir une taille appropriée
    if (scores == NULL) {
        fprintf(stderr, "Erreur lors de l'allocation mémoire\n");
        fclose(file);
        return NULL;
    }
    scores[0] = '\0';  // Initialise la chaîne de caractères vide

    char line[256];
    while (fgets(line, sizeof(line), file) != NULL) {
        strcat(scores, line);  // Concatène chaque ligne au contenu
    }

    fclose(file);
    return scores;
}


static gboolean expose_event_reaction(GtkWidget *widget, GdkEventExpose *event, gpointer data){
  cairo_t* cr = gdk_cairo_create(widget->window);
  //Fond gris (à remettre en blanc éventuellement)
  cairo_set_source_rgb(cr, 0.5, 0.5, 0.5);
  cairo_paint(cr);
  cairo_stroke(cr);
  draw_horizontal_line(widget);
  cairo_destroy(cr);

  return TRUE;
}// fin expose_event_reaction()


// Fonction de rappel pour la pression des touches
gboolean on_key_pressed(GtkWidget *widget, GdkEventKey *event, gpointer user_data) {
    ControleurTetris *controleur = (ControleurTetris *)user_data;

    switch (event->keyval) {
        case GDK_Left:
            // Déplacement gauche
            on_button_left_clicked(controleur->pLeftButton, controleur);
            return TRUE;
        case GDK_Down:
            // Déplacement bas
            on_button_down_clicked(controleur->pDownButton, controleur);
            return TRUE;
        case GDK_Right:
            // Déplacement droite
            on_button_right_clicked(controleur->pRightButton, controleur);
            return TRUE;
        default:
            return FALSE;
    }
}

ControleurTetris *create_controleur_tetris(ModelTetris *model, ViewTetris *view){
    assert(view != NULL);
    ControleurTetris *controleur = malloc(sizeof(ControleurTetris));
    if(controleur == NULL){
        printf("Erreur de l'allocation de mémoire pour controleur");
        return NULL;
    }
    
    controleur->pDownButton = NULL;
    controleur->model = model;
    controleur->view = view;

    return controleur;
}// fin create_controleur_tetris()

void destroy_controleur_tetris(ControleurTetris *controleur){
    assert(controleur != NULL);

    //destroy_view_tetris(controleur->view);

    free(controleur);
}// fin destroy_controleur_tetris()

ControleurTetris *set_down_button(ControleurTetris *controleur, GtkWidget *pDownButton){
    assert(controleur != NULL && pDownButton != NULL);

    controleur->pDownButton = pDownButton;

    return controleur;
}// fin set_down_button()

ControleurTetris *set_new_button(ControleurTetris *controleur, GtkWidget *pButtonNew){
    assert(controleur != NULL && pButtonNew != NULL);

    controleur->pButtonNew = pButtonNew;

    return controleur;
}// fin set_new_button()

static gint tic(gpointer data){
    ControleurTetris *controleur = (ControleurTetris*)data;

    ModelTetris *model = controleur->view->model;
    if(get_inGame(model) == TRUE){
        if(isButtonDown){
        isButtonDown = FALSE;
        delayCounter = 6;
        }
        delayCounter--;
        show_value_delay(controleur->view, delayCounter);
            if(delayCounter == 0){
                on_button_down_clicked(controleur->pDownButton, (gpointer)controleur);
                delayCounter = 6;
            }
            g_timeout_add (1000, tic, (gpointer)controleur);
    }
    return 0;
}// fin gint tic()

static void end_game(ControleurTetris *controleur) {
    assert(controleur != NULL);
    ModelTetris *model = controleur->view->model;
    set_inGame(model, FALSE);
    GameGrid *grid = get_gameGrid(controleur->model);
    clear_grid(grid);
    set_grid(controleur->view->model, grid);

    // Création de la boîte de dialogue
    GtkWidget *dialog = gtk_dialog_new_with_buttons("Partie Perdue !", GTK_WINDOW(controleur->view->window), GTK_DIALOG_MODAL, "OK", GTK_RESPONSE_OK, NULL);

    // Création d'une boîte pour le contenu
    GtkWidget *content_area = gtk_dialog_get_content_area(GTK_DIALOG(dialog));

    // Création d'une étiquette avec le message
    gchar *message = g_strdup_printf("Nombre de pièces posées : %u\n Attention : si vous souhaitez rejouer \n il faut redémarrer le jeu (./tetris)", piecePlaced);
    GtkWidget *label = gtk_label_new(message);
    g_free(message);

    // Ajout de l'étiquette à la boîte de contenu
    gtk_container_add(GTK_CONTAINER(content_area), label);

    // Création de l'entrée de texte
    GtkWidget *entry = gtk_entry_new();
    gtk_entry_set_text(GTK_ENTRY(entry), "Veuillez entrer votre nom");

    // Ajout de l'entrée de texte à la boîte de contenu
    gtk_container_add(GTK_CONTAINER(content_area), entry);
    gtk_widget_set_size_request(dialog, 300, 200);

    // Affichage de la boîte de dialogue et attente de la réponse
    gtk_widget_show_all(dialog);
    gint result = gtk_dialog_run(GTK_DIALOG(dialog));

    // Récupération du texte entré par l'utilisateur
    if (result == GTK_RESPONSE_OK) {
        const gchar *name = gtk_entry_get_text(GTK_ENTRY(entry));
        // Ajout du joueur avec le nom et le score dans le fichier texte
        add_player_to_file(name, get_score_in_model(model));
    }

    // Destruction de la boîte de dialogue
    gtk_widget_destroy(dialog);

    delayCounter = 6;
}//fin end_game()


void on_button_new_clicked(GtkWidget *pButtonNew, gpointer data){
    ControleurTetris *controleur = (ControleurTetris *)data;
    delayCounter = 6;
    piecePlaced = 0;
    isButtonNew = TRUE;
    ModelTetris *model = get_model_in_view(controleur->view);
    set_inGame(model, TRUE);
    set_score_in_model(model, 0);
    show_score(controleur->view, 0);
    GameGrid *grid = get_gameGrid(model);

    clear_grid(grid);

    gtk_widget_show(get_value_delay(controleur->view));
    
    GdkEventExpose *event;
    expose_event_reaction(get_drawingArea(controleur->view), event, data);
    //g_timeout_add(1000,tic, (gpointer)controleur);
    int pieceID;
    if(controlerCount == 0){
        g_timeout_add(1000, tic, (gpointer)controleur);
    }

    pieceID = draw_piece(grid);
    set_current_piece_id(model, pieceID);
    set_grid(model, grid);
    draw_cube(controleur->view, grid);
    
    controlerCount++;
   
    if(grid == NULL){
        clear_grid(grid);
        set_inGame(model, FALSE);
        return;
    }
  
}// fin on_button_new_clicked()

void on_button_down_clicked(GtkWidget *pDownButton, gpointer data){
    ControleurTetris *controleur = (ControleurTetris *)data;
    GameGrid *grid = get_gameGrid(controleur->view->model);

    ModelTetris *model = controleur->view->model;
    int pieceID = get_current_piece_id(model);
    
    grid = put_piece_down(grid, pieceID);
    
    if(grid == NULL){
        set_inGame(model, FALSE);
        end_game(controleur);
        GdkEventExpose *event;
        expose_event_reaction(get_drawingArea(controleur->view), event, data);
        isButtonNew = FALSE;
        return;
    }
    
    int rows = 0;
    rows = determine_rows_for_score(grid);
    
    calculate_score(controleur->view->model, rows);
    unsigned int score = get_score_in_model(model);
    show_score(controleur->view, score);
    set_grid(controleur->view->model, grid);
    draw_cube(controleur->view, grid);
    grid = complete_row(grid);
    grid = free_spawing_zone(grid);
    GdkEventExpose *event;

    expose_event_reaction(get_drawingArea(controleur->view), event, data);

    int pieceID2 = draw_piece(grid);
    set_current_piece_id(model, pieceID2);

    set_grid(controleur->view->model, grid);
    draw_cube(controleur->view, grid);

    set_score_in_model(controleur->view->model, score);
    isButtonDown = TRUE;
    piecePlaced++;
}// fin on_button_down_clicked()


void on_button_end_clicked(GtkWidget *pEndButton, gpointer data){
    ControleurTetris *controleur = (ControleurTetris*)data;
    ModelTetris *model = controleur->view->model;
    GameGrid *grid = get_gameGrid(controleur->view->model);
    GdkEventExpose *event;
    expose_event_reaction(get_drawingArea(controleur->view), event, data);
    gtk_widget_hide(get_value_delay(controleur->view));
    clear_grid(grid);
}// fin on_button_end_clicked()

void on_button_right_clicked(GtkWidget *pRightButton, gpointer data){
    ControleurTetris *controleur = (ControleurTetris*)data;

    ModelTetris *model = controleur->view->model;
    GameGrid *grid = get_gameGrid(model);

    GdkEventExpose *event;
    expose_event_reaction(get_drawingArea(controleur->view), event, data);
    

    int pieceID = get_current_piece_id(model);

    move_piece_right(grid, pieceID);
    
    draw_cube(controleur->view, grid);

}// fin on_button_right_clicked()

void on_button_left_clicked(GtkWidget *pLeftButton, gpointer data){
    ControleurTetris *controleur = (ControleurTetris*)data;

    ModelTetris *model = controleur->view->model;
    GameGrid *grid = get_gameGrid(model);

    GdkEventExpose *event;
    expose_event_reaction(get_drawingArea(controleur->view), event, data);
    
    int pieceID = get_current_piece_id(model);

    move_piece_left(grid, pieceID);

    draw_cube(controleur->view, grid);
}// fin on_button_left_clicked()
