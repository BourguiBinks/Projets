/**
 * \file modele_tetris.h
 * \author Alexandre Bourguignon
 * \author Julien Peffer
 * \brief Gestion du jeu tetris via une approche MVC. Ce fichier contient les déclarations de types et les prototypes
 * des fonctions pour le modèle du jeu tetris
 * \version 0.1
 * \date 2023-04-26
 * INFO0030 : Projet 4
 * 
 */

#ifndef __MODELE_TETRIS__
#define __MODELE_TETRIS__

#include "vue_tetris.h"

typedef struct ViewTetris_t ViewTetris;

/**
 * \brief type opaque du modele pour le tetris.
 */
typedef struct ModelTetris_t ModelTetris;

/**
 * \brief type opaque du stick pour le tetris.
 */
typedef struct Stick_t Stick;

/**
 * \brief type opaque du block pour le tetris.
 */
typedef struct Block_t Block;

/**
 * \brief type opaque du te pour le tetris.
 */
typedef struct Te_t Te;

/**
 * \brief type opaque de la Cellule pour le tetris.
 */
typedef struct Cell_t Cell;
    
/**
 * \brief type opaque pour la grille de jeu
*/
typedef struct GameGrid_t GameGrid;

/**
 * \fn unsigned int get_block_height(Block *block)
 * \brief Accesseur en lecture pour le champ height dans la structure Block
 *
 * \param block la structure Block (!= NULL)
 */
unsigned int get_block_height(Block *block);

/**
 * \fn unsigned int get_block_width(Block *block)
 * \brief Accesseur en lecture pour le champ width dans la structure Block
 *
 * \param block la structure Block (!= NULL)
 */
unsigned int get_block_width(Block *block);

/**
 * \fn unsigned int get_stick_height(Stick *stick)
 * \brief Accesseur en lecture pour le champ height dans la structure Stick
 *
 * \param block la structure Stick (!= NULL)
 */
unsigned int get_stick_height(Stick *stick);

/**
 * \fn unsigned int get_stick_width(Stick *stick)
 * \brief Accesseur en lecture pour le champ width dans la structure Stick
 *
 * \param block la structure Stick (!= NULL)
 */
unsigned int get_stick_width(Stick *stick);

/**
 * \fn unsigned int get_te_width(Te *te);
 * \brief Accesseur en lecture pour le champ width dans la structure Te
 *
 * \param block la structure Te (!= NULL)
 */
unsigned int get_te_width(Te *te);

/**
 * \fn unsigned int get_te_height(Te *te);
 * \brief Accesseur en lecture pour le champ height dans la structure Te
 *
 * \param block la structure Te (!= NULL)
 */
unsigned int get_te_height(Te *te);

unsigned int get_score_in_model(ModelTetris *model);

ModelTetris *set_score_in_model(ModelTetris *model, unsigned int score);

/**
 * \fn ModelTetris *create_model_tetris();
 * \brief Crée un modèle pour le jeu tetris
 *
 * \return ModelTetris *, un pointeur vers un modèle du jeu tetris.
 *         NULL en cas d'erreur
 */
ModelTetris *create_model_tetris();

/**
 * \fn void destroy_model_tetris(ModelTetris *model);
 * \brief Libère la mémoire allouée pour une structure de type ModelTetris
 *
 * \param model un pointeur vers une structure ModelTetris (!= NULL)
 * 
 */
void destroy_model_tetris(ModelTetris *model);

/**
 * \fn GameGrid *place_stick(GameGrid *grid)
 * \brief Place un stick en haut de la zone de jeu dans la grille aléatoirement
 * 
 * \param grid la grille de jeu sous forme de liste chainée (!= NULL)
 * 
 * \return GameGrid *, un pointeur vers une structure Gamegrid
*/
GameGrid *place_stick(GameGrid *grid);

/**
 * \fn GameGrid *place_block(GameGrid *grid)
 * \brief Place un block en haut de la zone de jeu dans la grille aléatoirement
 * 
 * \param grid la grille de jeu sous forme de liste chainée (!= NULL)
 * 
 * \return GameGrid *, un pointeur vers une structure Gamegrid
*/
GameGrid *place_block(GameGrid *grid);

/**
 * \fn GameGrid *place_te(GameGrid *grid)
 * \brief Place un te en haut de la zone de jeu dans la grille aléatoirement
 * 
 * \param grid la grille de jeu sous forme de liste chainée (!= NULL)
 * 
 * \return GameGrid *, un pointeur vers une structure Gamegrid
*/
GameGrid *place_te(GameGrid *grid);

GameGrid *place_el1(GameGrid *grid);

GameGrid *place_el2(GameGrid *grid);

GameGrid *place_couche(GameGrid *grid);

GameGrid *place_biais(GameGrid *grid);

GameGrid *place_batonVertical(GameGrid *grid);
/**
 * \fn int draw_piece(GameGrid *grid)
 * \brief Place une pièce aléatoire en haut de la zone de jeu dans la grille
 * 
 * \param grid la grille de jeu sous forme de liste chainée (!= NULL)
 * 
 * \return int, l'identifiant de la pièce dessinée
*/
int draw_piece(GameGrid *grid);

/**
 * \fn gboolean get_inGame(ModelTetris *model)
 * \brief Accesseur en lecture du champ inGame de la structure model
 * 
 * \param model la structure model (!= NULL)
 * 
 * \return gboolean, un booléen
*/
gboolean get_inGame(ModelTetris *model);

/**
 * \fn ModelTetris *set_inGame(ModelTetris *model, gboolean inGame)
 * \brief Accesseur en écriture du champ inGame de la structure model
 * 
 * \param model la structure model (!= NULL)
 * \param inGame le booléen nous indiquant si on est en jeu ou non
 * 
 * \return ModelTetris *, un pointeur vers une structure model
*/
ModelTetris *set_inGame(ModelTetris *model, gboolean inGame);

/**
 * \fn ModelTetris *set_grid(ModelTetris *model, GameGrid *grid)
 * \brief Accesseur en écriture du champ grid de la structure model
 * 
 * \param model la structure model (!= NULL)
 * \param inGame le booléen nous indiquant si on est en jeu ou non
 * 
 * \return ModelTetris *, un pointeur vers une structure model
*/
ModelTetris *set_grid(ModelTetris *model, GameGrid *grid);

/**
 * \fn ModelTetris *set_current_piece_id(ModelTetris *model, int id)
 * \brief Accesseur en écriture du champ currentPieceId de la structure model
 * 
 * \param model la structure model (!= NULL)
 * \param id l'identifiant de la pièce dessinée
 * 
 * \return ModelTetris *, un pointeur vers une structure model
*/
ModelTetris *set_current_piece_id(ModelTetris *model, int id);

/**
 * \fn int get_current_piece_id(ModelTetris *model)
 * \brief Accesseur en lecture du champ currentPieceId de la structure model
 * 
 * \param model la structure model (!= NULL)
 * 
 * \return int, l'identifiant de la pièce dessinée
*/
int get_current_piece_id(ModelTetris *model);

/**
 * \fn ModelTetris *set_current_piece_id(ModelTetris *model, int id)
 * \brief Accesseur en écriture du champ currentPieceId de la structure model
 * 
 * \param model la structure model (!= NULL)
 * \param id l'identifiant de la pièce dessinée
 * 
 * \return ModelTetris *, un pointeur vers une structure model
*/
ModelTetris *get_model_in_view(ViewTetris *view);

/**
 * \fn GameGrid *get_gameGrid(ModelTetris *model)
 * \brief Accesseur en lecture du champ gameGrid de la structure model
 * 
 * \param model la structure model (!= NULL)
 * 
 * \return GameGrid *, un pointeur vers la structure GameGrid
*/
GameGrid *get_gameGrid(ModelTetris *model);

/**
 * \fn void draw_cube(ViewTetris *view, GameGrid *grid)
 * \brief Dessine une pièce complète en haut de la grille de jeu
 * 
 * \param view la strutcure view (!= NULL)
 * \param grid la structure grid (!= NULL)
*/
void draw_cube(ViewTetris *view, GameGrid *grid);

/**
 * \fn void print_list(Cell* head)
 * \brief Affiche chaque elements de chaque liste.
 *
 * \param head une variable contenant l'adresse en mémoire qui pointe vers une instance de la structure Cell.
 */
void print_list(Cell* head);

/**
 * \fn int clear_grid(GameGrid *grid)
 * \brief Remet toute la grille de jeu à NULL.
 *
 * \param grid une variable contenant l'adresse en mémoire qui pointe vers une instance de la structure GameGrid.
 *
 * \return isClear
 */
int clear_grid(GameGrid *grid);

/**
 * \fn void set_at(GameGrid *grid, int i, int j, char *c)
 * \brief Place un caractere à la i-eme liste et j-eme colonne.
 *
 * \param grid une variable contenant l'adresse en mémoire qui pointe vers une instance de la structure GameGrid.
 * \param i une variable contenant l'indexe de la liste.
 * \param j une variable contenant l'indexe de la colonne.
 * \param c une variable contenant le caractère à insérer.
 */
void set_at(GameGrid *grid, int i, int j, char *c);

/**
 * \fn int find_piece(GameGrid *grid)
 * \brief Trouve l'indexe de la colonne ou se trouve le premier cube.
 *
 * \param grid une variable contenant l'adresse en mémoire qui pointe vers une instance de la structure GameGrid.
 *
 * \return j, une variable contenant l'indexe.
 */
int find_piece(GameGrid *grid);

/**
 * \fn GameGrid *put_piece_down(GameGrid *grid, int id)
 * \brief Déplace la piece aléatoirement choisie vers la position la plus basse possible.
 *
 * \param grid une variable contenant l'adresse en mémoire qui pointe vers une instance de la structure GameGrid.
 * \param id une variable qui distingue les différentes pièces.
 *
 * \return grid, un pointeur vers une instance de la structure GameGrid.
 *         NULL en cas d'erreur.
 */
GameGrid *put_piece_down(GameGrid *grid, int id);

/**
 * \fn void move_piece_right(GameGrid *grid, int pieceID)
 * \brief Déplace la piece aléatoirement choisie d'une unité vers la droite.
 *
 * \param grid une variable contenant l'adresse en mémoire qui pointe vers une instance de la structure GameGrid.
 * \param pieceID une variable qui distingue les différentes pièces.
 */
void move_piece_right(GameGrid *grid, int pieceID);

/**
 * \fn void move_piece_left(GameGrid *grid, int pieceID)
 * \brief Déplace la piece aléatoirement choisie d'une unité vers la gauche.
 *
 * \param grid une variable contenant l'adresse en mémoire qui pointe vers une instance de la structure GameGrid.
 * \param pieceID une variable qui distingue les différentes pièces.
 */
void move_piece_left(GameGrid *grid, int pieceID);

/**
 * \fn void calculate_score(ModelTetris *model, unsigned int rows)
 * \brief Calcule le score actuel de la partie en cours
 *
 * \param model la structure model.
 * \param rows le nombre de lignes complètes.
 */
void calculate_score(ModelTetris *model, unsigned int rows);

/**
 * \fn int determine_rows_for_score(GameGrid *grid)
 * \brief Détermine le nombre de lignes complètes dans une grille
 *
 * \param grid une variable contenant l'adresse en mémoire qui pointe vers une instance de la structure GameGrid.
 * \return le nombre de lignes complètes dans la grille
 */ 
int determine_rows_for_score(GameGrid *grid);

/**
 * \fn GameGrid *free_spawing_zone(GameGrid *grid)
 * \brief Met à NULL les 2 premières listes de la grille (là où apparaissent les pièces)
 * 
 * \param grid une variable contenant l'adresse en mémoire qui pointe vers une instance de la structure GameGrid.
 * 
 * \return la grille de jeu
 */
GameGrid *free_spawing_zone(GameGrid *grid);

/**
 * \fn char* get_at(GameGrid* grid, unsigned int row, unsigned int column)
 * \brief Permet de récupérer le contenu d'une celulle dans une liste
 * 
 * \param grid une variable contenant l'adresse en mémoire qui pointe vers une instance de la structure GameGrid.
 * \param row la liste
 * \param column la columns
 * \return le caractère se trouvant à l'emplacement (rows, columns) dans la grille
 */
char* get_at(GameGrid* grid, unsigned int row, unsigned int column);

/**
 * \fn GameGrid *complete_row(GameGrid *grid)
 * \brief Permet d'effacer une ligne quand elle est remplie et déplacer toutes celles au dessus d'une ligne en dessous
 * 
 * \param grid une variable contenant l'adresse en mémoire qui pointe vers une instance de la structure GameGrid. 
 * 
 * * \return la grille de jeu
 */
GameGrid *complete_row(GameGrid *grid);
#endif