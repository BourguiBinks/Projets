/**
 * \file vue_tetris.h
 * \author Alexandre Bourguignon
 * \author Julien Peffer
 * \brief Gestion du jeu tetris via une approche MVC. Ce fichier contient les déclarations de types et les prototypes
 * des fonctions pour la vue du jeu tetris.
 * \version 0.1
 * \date 2023-04-26
 * INFO0030 : Projet 4
 * 
 * 
 */

#ifndef __VUE_TETRIS__
#define __VUE_TETRIS__
#include "modele_tetris.h"

typedef struct ModelTetris_t ModelTetris;

typedef struct GameGrid_t GameGrid;

/**
 * \brief Implémentation de la structure de données de la vue pour le tetris.
 */
typedef struct ViewTetris_t{
    GtkWidget *window; /*!< la fenêtre GTK*/
    GtkWidget *drawingArea; /*!< la zone de jeu*/
    GtkWidget *valueDelay; /*!< le widget qui affiche le délai*/
    GtkWidget *pScore; /*!< le widget qui affiche le score */
    GtkWidget *entry;
    ModelTetris *model; /*!< la structure model*/
}ViewTetris;

/**
 * \fn GtkWidget *create_menu_zone_1(GtkWidget *window)
 * \brief Crée le menu en haut de la fenêtre avec l'onglet Partie et Aide
 *
 * \param window la fenêtre de jeu (!= NULL)
 * 
 */
GtkWidget *create_menu_zone_1(GtkWidget *window);

/**
 * \fn static void draw(GtkWidget *widget, unsigned int x, unsigned int y);
 * \brief Dessine un cube aux coordonnées (x,y) dans la zone de jeu
 *
 * \param widget, le widget en cause (drawingArea en l'occurrence)
 * \param x la coordonée sur l'axe x
 * \param x la coordonée sur l'axe x-y
 */
void draw(GtkWidget *widget, unsigned int x, unsigned int y);

/**
 * \fn ViewTetris *set_window(ViewTetris *view, GtkWidget *window)
 * \brief Accesseur en écriture pour le champ window dans la structure view
 *
 * \param view la structure view (!= NULL)
 * \param window la fenêtre GTK
 */
ViewTetris *set_window(ViewTetris *view, GtkWidget *window);

/**
 * \fn ViewTetris *set_value_delay(ViewTetris *view, GtkWidget *valueDelay)
 * \brief Accesseur en écriture pour le champ valueDelay dans la structure view
 *
 * \param view la structure view (!= NULL)
 * \param window le widget servant à afficher le délai (!= NULL)
 */
ViewTetris *set_value_delay(ViewTetris *view, GtkWidget *valueDelay);

ViewTetris *set_score_in_view(ViewTetris *view, GtkWidget *scoreLabel);

/**
 * \fn GtkWidget *get_value_delay(ViewTetris *view)
 * \brief Accesseur en lecture pour le champ valueDelay dans la structure view
 *
 * \param view la structure view (!= NULL)
 */
GtkWidget *get_value_delay(ViewTetris *view);

GtkWidget *get_score_in_view(ViewTetris *view);

/**
 * \fn ViewTetris *create_view_tetris()
 * \brief Crée une vue pour le jeu tetris
 *
 * \return ViewTetris *, un pointeur vers une vue du jeu tetris.
 *         NULL en cas d'erreur
 */
ViewTetris *create_view_tetris(ModelTetris *model);

/**
 * \fn void destroy_view_tetris(ViewTetris *view)
 * \brief Libère la mémoire allouée pour une structure de type ViewTetris
 *
 * \param view, un pointeur vers une structure ViewTetris (!= NULL)
 * 
 */
void destroy_view_tetris(ViewTetris *view);

/**
 * \fn ViewTetris *set_model(ViewTetris *view, ModelTetris *model)
 * \brief Accesseur en écriture pour le champ model dans la structure view
 *
 * \param view la structure view (!= NULL)
 * \param model la structure model (!= NULL)
 */
ViewTetris *set_model(ViewTetris *view, ModelTetris *model);

/**
 * \fn ViewTetris *set_drawingArea(ViewTetris *view, GtkWidget *drawingArea)
 * \brief Accesseur en écriture pour le champ drawingArea dans la structure view
 *
 * \param view la structure view (!= NULL)
 * \param model la grille de dessin (!= NULL)
 */
ViewTetris *set_drawingArea(ViewTetris *view, GtkWidget *drawingArea);

/**
 * \fn GtkWidget *get_drawingArea(ViewTetris *view)
 * \brief Accesseur en lecture pour le champ drawingArea dans la structure view
 *
 * \param view la structure view (!= NULL)
 */
GtkWidget *get_drawingArea(ViewTetris *view);

/**
 * \fn GameGrid *place_stick(GameGrid *grid)
 * \brief Dessine un stick dans la grille de jeu dans la première liste
 *
 * \param view la structure grid (!= NULL)
 */
GameGrid *place_stick(GameGrid *grid);

/**
 * \fn GameGrid *place_block(GameGrid *grid)
 * \brief Dessine un block dans la grille de jeu dans la première et deuxième liste
 *
 * \param view la structure grid (!= NULL)
 */
GameGrid *place_block(GameGrid *grid);

/**
 * \fn GameGrid *place_te(GameGrid *grid)
 * \brief Dessine un te dans la grille de jeu dans la première et deuxième liste
 *
 * \param view la structure grid (!= NULL)
 */
GameGrid *place_te(GameGrid *grid);

/**
 * \fn int draw_piece(GameGrid *grid)
 * \brief Dessine une pièce au hasard parmi les 3 pièces dans grille de jeu dans la première et deuxième liste
 *
 * \param view la structure grid (!= NULL)
 * \return l'identifiant de la pièce créée
 */
int draw_piece(GameGrid *grid);
/**
 * \fn void show_value_delay(ViewTetris *view, unsigned int n1)
 * \brief Affiche le délai et met à jour le label.
 *
 * \param view la structure view (!= NULL)
 * \param n1 le compteur du délai
 */
void show_value_delay(ViewTetris *view, unsigned int n1);

/**
 * \fn void show_score(ViewTetris *view)
 * \brief Affiche le score et met à jour le label.
 *
 * \param view la structure view (!= NULL)
 */
void show_score(ViewTetris *view, unsigned int score);
/**
 * \fn void draw_horizontal_line(GtkWidget *drawingArea)
 * \brief Dessine la ligne rouge sur la zone de jeu pour délimiter l'apparition des pièces
 * 
 * \param drawingArea la zone de jeu
 */
void draw_horizontal_line(GtkWidget *drawingArea);


#endif
