/**
 * \file modele_tetris.c
 * \author Alexandre Bourguignon
 * \author Julien Peffer
 * \brief Ce fichier contient le modèle du jeu tetris
 * \version 0.1
 * \date 2023-04-26
 * INFO0030 : Projet 4
 * 
 */

#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <gtk/gtk.h>

#include "modele_tetris.h"
#include "vue_tetris.h"


#define COLUMNS 10
#define ROWS 17

// constante pour différencier les différentes pièces.
const int stickID = 1;
const int blockID = 2;
const int teID = 3;
const int el1ID = 4;
const int el2ID = 5;
const int elcouche = 6;
const int biais = 7;
const int batonVertical = 8;
const int totalPieces = 8;

/**
 * \brief Implémentation du modèle pour le tetris.
*/
struct ModelTetris_t{
    gboolean inGame; /*!< Permet de déterminer si nous sommes dans une partie ou non. */
    GameGrid *grid; /*!< La grille de jeu*/
    int currentPieceId; /*!< L'identifiant de la dernière pièce dessinée */
    unsigned int score; /*!< le score */
};
/**
 * \brief Implémentation de la grille de jeu pour le tetris.
*/
struct GameGrid_t{
    unsigned int rows; /*!< nombre de lignes composant la grille */
    unsigned int columns; /*!< nombre de colonnes composant la grille */
    Cell **head; /*!< Tableau de pointeurs qui pointent vers la tête de chaque liste de la grille */
};
/**
 * \brief Implémentation de la pièce baton pour le tetris.
 */
struct Stick_t{
    unsigned int height; /*!< hauteur de la piece */
    unsigned int width; /*!< largeur de la piece */
    char *draw; /*!< tableau de chaînes de caractères */
};

/**
 * \brief Implémentation de la pièce block pour le tetris.
 */
struct Block_t{
    unsigned int height; /*!< hauteur de la piece */
    unsigned int width; /*!< largeur de la piece */
    char *draw; /*!< tableau de chaîne de caractères */
};

/**
 * \brief Implémentation de la pièce Té pour le tetris.
 */
struct Te_t{
    unsigned int height; /*!< hauteur de la piece */
    unsigned int width; /*!< largeur de la piece */
    char *draw; /*!< tableau de chaîne de caractères */
};

/**
 * \brief Implémentation de la cellule pour le tetris.
 */
struct Cell_t{
    void *data; /*!< partie utile de la cellule */
    Cell *next; /*!< partie liante de la cellule */
};

//=================================================================
/**
 * \fn static int give_random_piece()
 * \brief Donne un nombre entre 0 et 4 correspondant à une des trois pièces
 * 
 * \return 0 pour le stick, 1 pour le block, 2 pour le te, 3 pour le el (1) et 4 pour le el (2)
*/
static int give_random_piece();

/**
 * \fn static Stick *create_stick()
 * \brief Crée un pointeur vers une structure Stick
 * 
 * \return Stick *, un pointeur vers une structure Stick
 *         NULL en cas d'erreur
*/
static Stick *create_stick();

/**
 * \fn static Block *create_block()
 * \brief Crée un pointeur vers une structure Block
 * 
 * \return Block *, un pointeur vers une structure Block
 *         NULL en cas d'erreur
*/
static Block *create_block();
/**
 * \fn static te *create_te()
 * \brief Crée un pointeur vers une structure Te
 * 
 * \return Te *, un pointeur vers une structure Te
 *         NULL en cas d'erreur
*/
static Te *create_te();

/**
 * \fn static GameGrid *create_game_grid(void)
 * \brief Crée un pointeur vers une structure GameGrid
 * 
 * \return GameGrid *, un pointeur vers une structure GameGrid
 *         NULL en cas d'erreur
*/
static GameGrid *create_game_grid(void);

/**
 * \fn static void free_list(Cell *head);
 * \brief Libère la mémoire allouée pour une structure de type Cell
 *
 * \param head un pointeur vers une structure Cell
 * 
 */
static void free_list(Cell *head);

/**
 * \fn static Cell *create_list();
 * \brief Crée une liste chainée
 *
 * \return Cell *, un pointeur vers une liste chainée
 *         NULL en cas d'erreur
 */
static Cell *create_list();

static Stick *create_stick(){

    Stick *newStick = malloc(sizeof(Stick));
    if(newStick == NULL){
        printf("Erreur d'allocation pour stick \n");
        return NULL;
    }
    newStick->height = 1;
    newStick->width = 4;

    return newStick;
}// fin create_stick()

static Block *create_block(){

    Block *newBlock = malloc(sizeof(Block));
    if(newBlock == NULL){
        printf("Erreur d'allocation pour le block\n");
        return NULL;
    }
    newBlock->height = 2;
    newBlock->width = 2;
}// fin create_block()

unsigned int get_block_height(Block *block){
    assert(block != NULL);

    return block->height;
}// fin get_block_height()
unsigned int get_block_width(Block *block){
    assert(block != NULL);

    return block->width;
}// fin get_block_width()

unsigned int get_stick_height(Stick *stick){
    assert(stick != NULL);

    return stick->height;
}// fin get_stick_height()

unsigned int get_stick_width(Stick *stick){
    assert(stick != NULL);

    return stick->width;
}// fin get_stick_width()

static Te *create_te(){

    Te *newTe = malloc(sizeof(Te));
    if(newTe == NULL){
        printf("Erreur d'allocation pour le Te\n");
        return NULL;
    }
    newTe->height = 2;
    newTe->width = 3;
}// fin create_te()

unsigned int get_te_width(Te *te){
    assert(te != NULL);

    return te->width;
}// fin get_te_width()

unsigned int get_te_height(Te *te){
    assert(te != NULL);

    return te->height;
}// fin get_te_height()

unsigned int get_score_in_model(ModelTetris *model){
    assert(model != NULL);
    return (model->score);
}// fin get_score_in_model()

ModelTetris *set_score_in_model(ModelTetris *model, unsigned int score){
    assert(model != NULL);
    model->score = score;

    return model;
}// fin set_score_in_model()

static GameGrid *create_game_grid(void){
    GameGrid *newGrid = malloc(sizeof(GameGrid));
    if(newGrid == NULL){
        printf("Erreur d'allocation de mémoire pour la grille de jeu !\n");
        return NULL;
    }
    newGrid->rows = 17;
    newGrid->columns = 10;
    newGrid->head = malloc(sizeof(Cell *) * newGrid->rows);
    for(unsigned int i = 0; i < newGrid->rows; i++){
          newGrid->head[i] = create_list();
          if(newGrid->head[i] == NULL){
            printf("Erreur de création d'une liste\n");
            return NULL;
          }
    }
    return newGrid;
}// fin create_game_grid()

ModelTetris *create_model_tetris(){
    ModelTetris *model = malloc(sizeof(ModelTetris));
    if(model == NULL){
        printf("Impossible d'allouer de la mémoire pour le modèle\n");
        return NULL;
    }
    model->grid = create_game_grid();
    if(model->grid == NULL){
        free(model);
        return NULL;
    }
    model->inGame = FALSE; //Par défaut inGame est mit à FALSE
    

    return model;
}// fin create_model_tetris()

gboolean get_inGame(ModelTetris *model){
    assert(model != NULL);

    return model->inGame;
}// fin get_inGame()

ModelTetris *set_inGame(ModelTetris *model, gboolean inGame){
    assert(model != NULL && (inGame == TRUE || inGame == FALSE));

    model->inGame = inGame;

    return model;
}// fin set_inGame()

GameGrid *get_gameGrid(ModelTetris *model){
    assert(model != NULL);
    assert(model->grid != NULL);

    return model->grid;
}//fin get_gameGrid()

ModelTetris *set_grid(ModelTetris *model, GameGrid *grid){
    assert(model != NULL);
    assert(grid != NULL);

    model->grid = grid;

    return model;
}// fin set_grid()

ModelTetris *set_current_piece_id(ModelTetris *model, int id){
    assert(id == 0 || id == 1 || id == 2 || id == 3 || id == 4 || id == 5 || id == 6 || id == 7 && model != NULL);
    model->currentPieceId = id;

    return model;
}// fin set_current_piece_id()

int get_current_piece_id(ModelTetris *model){
    assert(model != NULL);
    return(model->currentPieceId);

}// fin get_current_piece_id()

ModelTetris *get_model_in_view(ViewTetris *view){
    assert(view != NULL);
    return(view->model);
}// fin get_model_in_view()

static void free_list(Cell *head) {
    Cell *current = head;
    while (current != NULL) {
        Cell *next = current->next;
        free(current);
        current = next;
    }
}// fin free_list()

void destroy_model_tetris(ModelTetris *model){
    assert(model != NULL);
    for(unsigned int i = 0; i < ROWS; i++){
        free_list(model->grid->head[i]);
    }
    free(model->grid);
    free(model);
}// fin destroy_model_tetris()

GameGrid *place_stick(GameGrid *grid){
    assert(grid != NULL);
    
    Stick *newStick = create_stick();
    if(newStick == NULL){
        return NULL;
    }
    unsigned int width = get_stick_width(newStick);
    unsigned int x = rand() % 7;
    //printf("x = %u\n", x);
    for(unsigned int i = 0; i < width; i++){
        set_at(grid, 0, x + i, "@");
        //print_list(grid->head[0]);
    }
    
    free(newStick);
    return grid;
}// fin place_stick()

GameGrid *place_block(GameGrid *grid){
    assert(grid != NULL);
    
    Block *newBlock = create_block();
    if(newBlock == NULL){
        return NULL;
    }
    unsigned int width = get_block_width(newBlock);
    unsigned int height = get_block_height(newBlock);
    unsigned int x = rand() % 9;
    //printf("x = %u\n", x);
    for(unsigned int i = 0; i < height; i++){
        for(unsigned int j = 0; j < width; j++)
         set_at(grid, i, x + j, "@");
         //print_list(grid->head[0]);
    }
    
    free(newBlock);
    return grid;
}// fin place_block()

GameGrid *place_te(GameGrid *grid){
    assert(grid != NULL);
    
    Te *newTe= create_te();
    if(newTe == NULL){
        return NULL;
    }
    unsigned int width = get_te_width(newTe);
    unsigned int height = get_te_height(newTe);
    unsigned int x = rand() % 8;
    //printf("x = %u\n", x);
    for(unsigned int i = 0; i < width; i++){
            set_at(grid, 0, x + i, "@");
        }
    set_at(grid, 1, x + 1, "@");    
    
    free(newTe);
    return grid;
}// fin place_te()

GameGrid *place_el1(GameGrid *grid){
    assert(grid != NULL);

    unsigned int x = rand() % 8;
    unsigned int width = 3;
    for(unsigned int i = 0; i < width; i++)
        set_at(grid, 0, x + i, "@");

    set_at(grid, 1, x, "@");
    return grid;
}

GameGrid *place_el2(GameGrid *grid){
    assert(grid != NULL);

    unsigned int x = rand() % 8;
    unsigned int width = 3;
    for(unsigned int i = 0; i < width; i++)
        set_at(grid, 0, x + i, "@");

    set_at(grid, 1, x + 2, "@");
    return grid;
}

GameGrid *place_couche(GameGrid *grid){
    assert(grid != NULL);

    unsigned int x = rand() % 8;
    unsigned int width = 3;
    for(unsigned int i = 0; i < width; i++)
        set_at(grid, 1, x + i, "@");

    set_at(grid, 0, x + 2, "@");
    return grid;
}

GameGrid *place_biais(GameGrid *grid){
    assert(grid != NULL);

    unsigned int x = rand() % 8;
    unsigned int width = 3;
    set_at(grid, 0, x, "@");
    set_at(grid, 0, x + 1, "@");
    set_at(grid, 1, x + 1, "@");
    set_at(grid, 1, x + 2, "@");

    return grid;
}

GameGrid *place_batonVertical(GameGrid *grid){
    assert(grid != NULL);

    unsigned int x = rand() % 9;
    set_at(grid, 0, x, "@");
    set_at(grid, 1, x, "@");

    return grid;
}

static int give_random_piece(){

    int alea = (int)(rand()/(float)RAND_MAX * (totalPieces));
    return alea;
}// fin give_random_piece()

int draw_piece(GameGrid *grid){
    assert(grid != NULL);

    int randomPiece = give_random_piece();
    //printf("nombre : %d\n", randomPiece);
    switch(randomPiece){
        case 0:
        place_stick(grid);
        return 0;
        break;

        case 1:
        place_block(grid);
        return 1;
        break;

        case 2:
        place_te(grid);
        return 2;
        break;

        case 3:
        place_el1(grid);
        return 3;

        case 4:
        place_el2(grid);
        return 4;

        case 5:
        place_couche(grid);
        return 5;

        case 6:
        place_biais(grid);
        return 6;

        case 7:
        place_batonVertical(grid);
        return 7;

        default:
        printf("Erreur !\n");
        return -1;
        break;
    }
}// fin draw_piece()

static Cell *create_list(){
    Cell *head = NULL;
    for(int i = 0; i < 10; i++) {
        Cell *new_cell = malloc(sizeof(Cell));
        if(new_cell == NULL){
            printf("Problème d'allocation pour une cellule\n");
            return NULL;
        }
        new_cell->data = NULL;
        new_cell->next = NULL;

        if(head == NULL) {
            head = new_cell;
        } else{
            Cell *current = head;
            while(current->next != NULL) {
                current = current->next;
            }
            current->next = new_cell;
        }
    }
    return head;
}// fin create_list()

void print_list(Cell* head) {
    Cell* current = head;
    while (current != NULL) {
        if (current->data == NULL) {
            printf("NULL ");
        } else {
            printf("%s ", (char *)current->data);
        }
        current = current->next;
    }
    printf("\n");
}// fin print_list()

int clear_grid(GameGrid *grid) {
    int isClear = 0;
    Cell *current = NULL;
    for(unsigned int i = 0; i < ROWS; i++) {
        current = grid->head[i];
        for(unsigned int j = 0; j < COLUMNS; j++) {
            if (current->data != NULL){
                current->data = NULL;
                isClear = 1;
            }
            current = current->next;
        }
    }
    return isClear;
}// fin clear_grid()

void set_at(GameGrid *grid, int i, int k, char *c) {
    assert(grid != NULL);
    Cell *current = grid->head[i];
    int j = 0;

    // Parcourir la liste jusqu'à la ième cellule
    while (j < k && current != NULL) {
        current = current->next;
        j++;
    }

    // Vérifier si la ième cellule existe
    if (j == k && current != NULL) {
        current->data = c;
    } else {
        printf("La k-eme cellule n'existe pas\n");
    }
}// fin set_at()


void draw_cube(ViewTetris *view, GameGrid *grid){
    assert(grid != NULL);

  unsigned int x = 0;
  unsigned int y = 0;
  GtkWidget *drawingArea = get_drawingArea(view);
  for(unsigned int i = 0; i < ROWS; i++){  
    Cell* current = grid->head[i];
    while (current != NULL) {
        //printf("(%u, %u)", x, y);
        if (current->data != NULL) {
            draw(drawingArea, x, y);
        } 
            
        current = current->next;
        x++;
    }
    x = 0;
    y++;
  }
}// fin draw_cube()

int find_piece(GameGrid *grid){
    assert(grid != NULL);

    Cell *current = NULL;
        current = grid->head[0];
        for(unsigned int j = 0; j < grid->columns; j++) {
            if(current->data != NULL){
                return j;
            }
            current = current->next;
        }
}// fin find_piece()

int find_lowest_point(GameGrid *grid, int idPiece, unsigned int index){
    assert(grid != NULL && (idPiece == 0|| idPiece == 1 || idPiece == 2 || idPiece == 3 || idPiece == 4 || idPiece == 5 || idPiece == 6 || idPiece == 7));

    Cell *current = NULL;
    Cell *current2 = NULL;
    Cell *current3 = NULL;
    Cell *current4 = NULL;
    Cell *current5 = NULL;
    unsigned int lowest = 2;

    if(idPiece == 0){
    for(unsigned int i = 2; i < ROWS; i++) {
        current = grid->head[i];
        //printf("i = %u\n", i);
        //On parcourt les cellules jusqu'à l'index
        for(unsigned int j = 0; j < index; j++){
             current = current->next;
        }
        if(current->data == NULL && current->next->data == NULL && current->next->next->data == NULL && current->next->next->next->data == NULL){
            lowest++;
            current = NULL;
            if(i == 16){
                return i;
            }
        }
        else
            return lowest-1;
    }
    }
    else if(idPiece == 1){
        for(unsigned int i = 2; i < ROWS - 1; i++) {
        current2 = grid->head[i];
        current3 = grid->head[i + 1];
        //printf("i = %u\n", i);
        //On parcourt les cellules jusqu'à l'index
        for(unsigned int j = 0; j < index; j++){
             current2 = current2->next;
             current3 = current3->next;
        }
        if(current2->data == NULL && current2->next->data == NULL && current3->data == NULL && current3->next->data == NULL){
            lowest++;
            current2 = NULL;
            current3 = NULL;
            if(i == 16){
                return lowest--;
            }
        }
        else
            return lowest--;
        }
    }
    else if(idPiece == 2){
        for(unsigned int i = 2; i < ROWS - 1; i++) {
        current4 = grid->head[i];
        current5 = grid->head[i + 1];
        //printf("i = %u\n", i);
        //On parcourt les cellules jusqu'à l'index
        for(unsigned int j = 0; j < index; j++){
             current4 = current4->next;
             current5 = current5->next;
        }
        if(current4->data == NULL && current4->next->data == NULL && current4->next->next->data == NULL && current5->next->data == NULL){
            lowest++;
            current4 = NULL;
            current5 = NULL;
            if(i == 16){
                return lowest--;
            }
        }
        else
            return lowest--;
        }
    }

    else if(idPiece == 3){
        for(unsigned int i = 2; i < ROWS - 1; i++) {
        current4 = grid->head[i];
        current5 = grid->head[i + 1];
        //printf("i = %u\n", i);
        //On parcourt les cellules jusqu'à l'index
        for(unsigned int j = 0; j < index; j++){
             current4 = current4->next;
             current5 = current5->next;
        }
        if(current4->data == NULL && current4->next->data == NULL && current4->next->next->data == NULL && current5->data == NULL){
            lowest++;
            current4 = NULL;
            current5 = NULL;
            if(i == 16){
                return lowest--;
            }
        }
        else
            return lowest--;
        }

    }
    else if(idPiece == 4){
        for(unsigned int i = 2; i < ROWS - 1; i++) {
        current4 = grid->head[i];
        current5 = grid->head[i + 1];
        //printf("i = %u\n", i);
        //On parcourt les cellules jusqu'à l'index
        for(unsigned int j = 0; j < index; j++){
             current4 = current4->next;
             current5 = current5->next;
        }
        if(current4->data == NULL && current4->next->data == NULL && current4->next->next->data == NULL && current5->next->next->data== NULL){
            lowest++;
            current4 = NULL;
            current5 = NULL;
            if(i == 16){
                return lowest--;
            }
        }
        else
            return lowest--;
        }
    }

    else if(idPiece == 5){
        for(unsigned int i = 2; i < ROWS - 1; i++) {
        current4 = grid->head[i];
        current5 = grid->head[i + 1];
        //printf("i = %u\n", i);
        //On parcourt les cellules jusqu'à l'index
        for(unsigned int j = 0; j < index - 2; j++){
             current4 = current4->next;
             current5 = current5->next;
        }
        if(current5->data == NULL && current5->next->data == NULL && current5->next->next->data == NULL && current4->next->next->data== NULL){
            lowest++;
            current4 = NULL;
            current5 = NULL;
            if(i == 16){
                return lowest--;
            }
        }
        else
            return lowest--;
        }
    }

    else if(idPiece == 6){
        for(unsigned int i = 2; i < ROWS - 1; i++) {
        current4 = grid->head[i];
        current5 = grid->head[i + 1];
        //printf("i = %u\n", i);
        //On parcourt les cellules jusqu'à l'index
        for(unsigned int j = 0; j < index; j++){
             current4 = current4->next;
             current5 = current5->next;
        }
        if(current4->data == NULL && current4->next->data == NULL && current5->next->data == NULL && current5->next->next->data== NULL){
            lowest++;
            current4 = NULL;
            current5 = NULL;
            if(i == 16){
                return lowest--;
            }
        }
        else
            return lowest--;
        }
    }

    else if(idPiece == 7){
        for(unsigned int i = 2; i < ROWS - 1; i++){
            current4 = grid->head[i];
            current5 = grid->head[i + 1];

            for(unsigned int j = 0; j < index; j++){
                current4 = current4->next;
                current5 = current5->next;
            }
            if(current4->data == NULL && current5->data == NULL){
                lowest++;
                current4 = NULL;
                current5 = NULL;
                if(i == 16){
                    return lowest--;
                }
            }
            else
                return lowest--;
        }
    }
    return lowest--;
}// fin find_lowest_point()

GameGrid *put_piece_down(GameGrid *grid, int id){
    assert(grid != NULL);
    //Index va contenir la coordonnée x du début de la pièce (le premier cube)
    unsigned int index = find_piece(grid);
    //printf("Index = %d\n", index);
    unsigned int lowest = find_lowest_point(grid, id, index);
    //printf("Lowest point : %u\n", lowest);
    Cell *current = NULL;
    Cell *current2 = NULL;
    for(unsigned int i = 0; i < 2; i++) {
        current = grid->head[i];
        //On parcourt toute les cellules
        for(unsigned int j = 0; j < COLUMNS; j++){
            //Si on trouve un "@"
            if(current->data != NULL){
                //On vide la cellule 
                set_at(grid, i, j, "NULL");
            }
             current = current->next;
        }
    }
    // Descendre la pièce au plus bas
    if(id == 0){
        if(lowest < 2){
        printf("La partie est perdue !\n");
        return NULL;
    }
    for(unsigned int k = 0; k < 4; k++){
        set_at(grid, lowest, index + k, "@");
    }
    return grid;
    }
    else if(id == 1){
        if(lowest <= 2){
         printf("La partie est perdue !\n");
         return NULL;
        }
        for(unsigned int i = 0; i < 2; i++){
         for(unsigned int j = 0; j < 2; j++)
            set_at(grid, lowest + i - 1, index + j, "@");
      }
      return grid;
    }
    else if(id == 2){
        if(lowest <= 2){
         printf("La partie est perdue !\n");
        return NULL;
        }
        for(unsigned int i = 0; i < 3; i++){
            set_at(grid, lowest - 1, index + i, "@");
        }
        set_at(grid, lowest, index + 1, "@");    
        return grid;
    }
    else if(id == 3){
        if(lowest <= 2){
            printf("La partie est perdue!\n");
            return NULL;
        }
        for(unsigned int i = 0; i < 3; i++)
            set_at(grid, lowest - 1, index + i, "@");

        set_at(grid, lowest, index, "@");

        return grid;
    }

    else if(id == 4){
        if(lowest <= 2){
            printf("La partie est perdue!\n");
            return NULL;
        }
        for(unsigned int i = 0; i < 3; i++)
            set_at(grid, lowest - 1, index + i, "@");

        set_at(grid, lowest, index + 2, "@");

        return grid;
    }

     else if(id == 5){
        if(lowest <= 2){
            printf("La partie est perdue!\n");
            return NULL;
        }
        for(unsigned int i = 0; i < 3; i++)
            set_at(grid, lowest, index - i, "@");

        set_at(grid, lowest - 1, index, "@");

        return grid;
    }

    else if(id == 6){
        if(lowest <= 2){
            printf("La partie est perdue!\n");
            return NULL;
        }
        set_at(grid, lowest, index + 1, "@");
        set_at(grid, lowest, index + 2, "@");
        set_at(grid, lowest - 1, index, "@");
        set_at(grid, lowest - 1, index + 1, "@");
        return grid;
    }

    else if(id == 7){
        if(lowest <= 2){
            printf("La partie est perdue!\n");
            return NULL;
        }
        set_at(grid, lowest, index, "@");
        set_at(grid, lowest - 1, index, "@");
        return grid;
    }
    
    return grid;
}// fin put_piece_down()

void move_piece_right(GameGrid *grid, int pieceID){
    assert(grid != NULL);
    // Chercher la position de la pièce
    int col = find_piece(grid);
    
    // Vérifier qu'on peut déplacer la pièce à droite
    if(pieceID == 0){
        if(col < 6){
            // Cell *current = grid->head[0];
            // Si la cellule contient un cube, le déplacer vers la droite
            set_at(grid, 0, col, NULL);
            set_at(grid, 0, col + 4, "@");
            return;
                
        }
        return;   
    }else if(pieceID == 1){
        if(col < 8){
            for(int i = 0; i < 2; i++){
                set_at(grid, i, col, NULL);
                set_at(grid, i, col + 2, "@");
                
            }
            return;
        }
    }else if(pieceID == 2){
        if(col < 7){
             set_at(grid, 0, col, NULL);
             set_at(grid, 0, col + 3, "@");
             set_at(grid, 1, col + 1, NULL);
             set_at(grid, 1, col + 2, "@");
             return;
        }
        return;
    }
    else if(pieceID == 3){
        if(col < 7){
             set_at(grid, 0, col, NULL);
             set_at(grid, 0, col + 3, "@");
             set_at(grid, 1, col, NULL);
             set_at(grid, 1, col + 1, "@");
             return;
        }
        return;
    }
    else if(pieceID == 4){
        if(col < 7){
             set_at(grid, 0, col, NULL);
             set_at(grid, 0, col + 3, "@");
             set_at(grid, 1, col + 2, NULL);
             set_at(grid, 1, col + 3, "@");
             return;
        }
        return;
    }

    else if(pieceID == 5){
        if(col < 9){
             set_at(grid, 0, col, NULL);
             set_at(grid, 0, col + 1, "@");
             set_at(grid, 1, col - 2, NULL);
             set_at(grid, 1, col + 1, "@");
             return;
        }
        return;
    }

    else if(pieceID == 6){
        if(col < 7){
             set_at(grid, 0, col, NULL);
             set_at(grid, 0, col + 2, "@");
             set_at(grid, 1, col + 1, NULL);
             set_at(grid, 1, col + 3, "@");
             return;
        }
        return;
    }

    else if(pieceID == 7){
        if(col < 9){
            set_at(grid, 0, col, NULL);
            set_at(grid, 0, col + 1, "@");
            set_at(grid, 1, col, NULL);
            set_at(grid, 1, col + 1, "@");
            return;
        }
        return;
    }
}// fin move_piece_right()

void move_piece_left(GameGrid *grid, int pieceID){
    assert(grid != NULL);
    // Chercher la position de la pièce
    int col = find_piece(grid);
    
    // Vérifier qu'on peut déplacer la pièce à droite
    if(pieceID == 0){
        if(col > 0){
            set_at(grid, 0, col + 3, NULL);
            set_at(grid, 0, col - 1, "@");
            return; 
        }
        return;   
    }else if(pieceID == 1){
        if(col > 0){
            for(int i = 0; i < 2; i++){
                set_at(grid, i, col + 1, NULL);
                set_at(grid, i, col - 1, "@"); 
            }
            return;
        }
    }else if(pieceID == 2){
        if(col > 0){
             set_at(grid, 0, col + 2, NULL);
             set_at(grid, 0, col - 1, "@");
             set_at(grid, 1, col + 1, NULL);
             set_at(grid, 1, col, "@");
             return;
        }
        return;
    }

     else if(pieceID == 3){
        if(col > 0){
             set_at(grid, 0, col + 2, NULL);
             set_at(grid, 0, col - 1, "@");
             set_at(grid, 1, col, NULL);
             set_at(grid, 1, col - 1, "@");
             return;
        }
        return;
    }
    else if(pieceID == 4){
        if(col > 0){
             set_at(grid, 0, col + 2, NULL);
             set_at(grid, 0, col - 1, "@");
             set_at(grid, 1, col + 2, NULL);
             set_at(grid, 1, col + 1, "@");
             return;
        }
        return;
    }

    else if(pieceID == 5){
        if(col > 2){
             set_at(grid, 0, col, NULL);
             set_at(grid, 0, col - 1, "@");
             set_at(grid, 1, col, NULL);
             set_at(grid, 1, col - 3, "@");
             return;
        }
        return;
    }

    else if(pieceID == 6){
        if(col > 0){
             set_at(grid, 0, col + 1, NULL);
             set_at(grid, 0, col - 1, "@");
             set_at(grid, 1, col + 2, NULL);
             set_at(grid, 1, col, "@");
             return;
        }
        return;
    }
    else if(pieceID == 7){
        if(col > 0){
            set_at(grid, 0, col, NULL);
            set_at(grid, 0, col - 1, "@");
            set_at(grid, 1, col, NULL);
            set_at(grid, 1, col - 1, "@");
            return;
        }
        return;
    }
}// fin move_piece_left()

void calculate_score(ModelTetris *model, unsigned int rows){
    assert(model != NULL);

    switch(rows){
        case 1:
            model->score += 40;
            return;
            break;
        case 2:
            model->score += 100;
            return;
            break;
        case 3:
            model->score += 300;
            return;
            break;
        case 4:
            model->score += 1200;
            return;
            break;
        default:
            //printf("Erreur\n");
            return;
            break;
    }
}// fin calculate_score()

int determine_rows_for_score(GameGrid *grid){
    assert(grid != NULL);

    int rows = 0;
    Cell *current = NULL;
    for(unsigned int i = 2; i < ROWS; i++){
        current = grid->head[i];
        int isFullRow = 1; // on suppose que la ligne est complète
        for(unsigned int j = 0; j < COLUMNS; j++){
            if(current->data == NULL){
                isFullRow = 0; // on a trouvé une case vide, la ligne n'est pas complète
                break;
            }
            current = current->next;
        }
        if(isFullRow){
            rows++; // on incrémente le nombre de lignes complètes
        }
    }
    return rows;
}// fin determine_rows_for_score()

GameGrid *free_spawing_zone(GameGrid *grid){
    assert(grid != NULL);
    for(unsigned int i = 0; i < 2; i++){
        for(unsigned int j = 0; j < 10; j++){
            set_at(grid, i, j, NULL);
        }
    }
    return grid;
}// fin free_spawing_zone()

char* get_at(GameGrid* grid, unsigned int row, unsigned int column) {
    assert(grid != NULL && row < ROWS && column < COLUMNS);

    Cell* current = grid->head[row];
    for(unsigned int i = 0; i < column; i++) {
        current = current->next;
    }

    return current->data;
}// fin get_at()

GameGrid *complete_row(GameGrid *grid) {
    assert(grid != NULL);
    unsigned int count;
    int row_shift = 0; // nombre de lignes à décaler vers le bas
    gboolean shifted = FALSE; // vérifier si des lignes ont été décalées

    for(unsigned int i = 2; i < ROWS; i++) {
        Cell *current = grid->head[i];
        count = 0;
        while(current != NULL) {
            if(current->data != NULL) {
                count++;
            }
            current = current->next;
        }
        if(count == COLUMNS) {
            for(unsigned int k = i; k > 2; k--) {
                // décaler chaque ligne au-dessus de la ligne supprimée
                for(unsigned int j = 0; j < COLUMNS; j++) {
                    set_at(grid, k, j, get_at(grid, k-1, j));
                }
            }
            // mettre à NULL la première ligne
            for(unsigned int j = 0; j < COLUMNS; j++) {
                set_at(grid, 2, j, NULL);
            }
            row_shift++; // incrémenter le nombre de lignes décalées
            shifted = TRUE; // signaler que des lignes ont été décalées
        }
    }

    if (shifted) {
        // décaler les lignes vers le bas
        for(unsigned int i = ROWS - 1; i > 2; i--) {
            if(i < row_shift + 2) {
                break;
            }
            for(unsigned int j = 0; j < COLUMNS; j++) {
                set_at(grid, i, j, get_at(grid, i-row_shift+1, j));
            }
        }
        // mettre à NULL les lignes décalées
        for(unsigned int i = 2; i < row_shift + 2; i++) {
            for(unsigned int j = 0; j < COLUMNS; j++) {
                set_at(grid, i, j, NULL);
            }
        }
        //printf("Nombre de lignes supprimées : %d\n", row_shift);
    }

    return grid;
}// fin complete_row()
