/**
 * \file vue_tetris.c
 * \author Alexandre Bourguignon
 * \author Julien Peffer
 * \brief Ce fichier contient la vue du jeu tetris
 * \version 0.1
 * \date 2023-04-26
 * INFO0030 : Projet 4
 * 
 */

#include <gtk/gtk.h>
#include <assert.h>
#include <time.h>

#include "vue_tetris.h"
#include "modele_tetris.h"
#include "controleur_tetris.h"
#define SIZE_SQUARE 16
//==========================================================
static void on_score_tab_clicked(GtkWidget *widget, gpointer data);

/**
 * \fn static void information_dialog(GtkWidget *widget, gpointer data);
 * \brief Affiche la fenêtre de dialogue quand on clique sur à propos dans le menu Aide
 *
 * \param widget, le widget en cause.
 * \param data, un pointeur sur void.
 */
static void information_dialog(GtkWidget *widget, gpointer data);

GtkWidget *create_menu_zone_1(GtkWidget *window){

  //Création du menu
  GtkWidget *menu_bar = gtk_menu_bar_new();
  GtkWidget *game_menu = gtk_menu_new();
  GtkWidget *help_menu = gtk_menu_new();
  GtkWidget *help_item = gtk_menu_item_new_with_mnemonic("_Aide");
  GtkWidget *information_item = gtk_menu_item_new_with_mnemonic("_A Propos");
  GtkWidget *game_item = gtk_menu_item_new_with_mnemonic("_Partie");
  GtkWidget *new_game_item = gtk_menu_item_new_with_mnemonic("_Nouvelle Partie");
  GtkWidget *score_item = gtk_menu_item_new_with_mnemonic("_Score");
  GtkWidget *quit_item = gtk_image_menu_item_new_from_stock(GTK_STOCK_QUIT, NULL);
  GtkWidget *separator_item = gtk_separator_menu_item_new();

  //Attacher les items
  gtk_menu_item_set_submenu(GTK_MENU_ITEM(game_item), game_menu); //L'onglet Partie
  gtk_menu_shell_append(GTK_MENU_SHELL(game_menu), new_game_item); //Nouvelle partie
  
  gtk_menu_shell_append(GTK_MENU_SHELL(game_menu), score_item); // Ajoutez l'élément de menu "Score" au menu "Partie"
  gtk_menu_shell_append(GTK_MENU_SHELL(game_menu), separator_item);//Séparateur
  gtk_menu_shell_append(GTK_MENU_SHELL(game_menu), quit_item); //Quitter
  gtk_menu_shell_append(GTK_MENU_SHELL(menu_bar), game_item); //Ajout de l'onglet partie au menu
 
  gtk_menu_item_set_submenu(GTK_MENU_ITEM(help_item), help_menu);//L'onglet Aide
  gtk_menu_shell_append(GTK_MENU_SHELL(help_menu), information_item); //A propos
  gtk_menu_shell_append(GTK_MENU_SHELL(menu_bar), help_item); // Ajout de l'onglet Aide au menu
  
  //Ajout du signal
  g_signal_connect(G_OBJECT(quit_item), "activate", G_CALLBACK(gtk_main_quit), NULL);
  g_signal_connect(G_OBJECT(information_item), "activate", G_CALLBACK(information_dialog), NULL);
  g_signal_connect(G_OBJECT(score_item), "activate", G_CALLBACK(on_score_tab_clicked), window);

  return menu_bar;
}//fin create_menu_zone_1()

static void on_score_tab_clicked(GtkWidget *widget, gpointer data){

    // Création de la boîte de dialogue
    GtkWidget *dialog = gtk_dialog_new_with_buttons("TOP 10 des meilleurs scores", GTK_WINDOW(data), GTK_DIALOG_MODAL, "OK", GTK_RESPONSE_OK, NULL);

    // Création d'une boîte pour le contenu
    GtkWidget *content_area = gtk_dialog_get_content_area(GTK_DIALOG(dialog));

    // Création d'une étiquette pour afficher les scores
    // Vous pouvez remplacer cette étiquette par un TreeView pour une présentation plus sophistiquée
    char* scores = read_scores_from_file();
    if (scores != NULL) {
        // Affichage des scores dans une étiquette
        if(strlen(scores) == 0){
            GtkWidget *empty = gtk_label_new("Il n'y a encore aucun score pour l'instant !");
            gtk_container_add(GTK_CONTAINER(content_area), empty);
            gtk_widget_set_size_request(dialog, 300, 100);
            gtk_widget_show_all(dialog);
            gint result = gtk_dialog_run(GTK_DIALOG(dialog));
            gtk_widget_destroy(dialog);
            return;
        }
        
        GtkWidget *scores_label = gtk_label_new(scores);
        gtk_container_add(GTK_CONTAINER(content_area), scores_label);

        // Libération de la mémoire allouée pour les scores
        free(scores);
    }

    gtk_widget_set_size_request(dialog, 400, 300);
    // Affichage de la boîte de dialogue et attente de la réponse
    gtk_widget_show_all(dialog);
    gint result = gtk_dialog_run(GTK_DIALOG(dialog));

    // Destruction de la boîte de dialogue
    gtk_widget_destroy(dialog);
}


static void information_dialog(GtkWidget *widget, gpointer data){
    GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_INFO, GTK_BUTTONS_OK, "Jeu Tetris réalisé par Julien Peffer et Alexandre Bourguignon relatif au projet 4 en INFO0030 (29/04/2023). Pour tout rachat des droits du jeu veuillez nous contacter au numéro suivant : +32492176531");
    gtk_dialog_run(GTK_DIALOG(dialog));
    gtk_widget_destroy(dialog);
}// fin information_dialog()

ViewTetris *set_window(ViewTetris *view, GtkWidget *window){
    assert(view != NULL && window != NULL);
    view->window = window;
    return view;
}//fin set_window()

ViewTetris *set_value_delay(ViewTetris *view, GtkWidget *valueDelay){
    assert(view != NULL && valueDelay != NULL);
    view->valueDelay = valueDelay;
    return view;
}//fin set_window()

ViewTetris *set_score_in_view(ViewTetris *view, GtkWidget *scoreLabel){
    assert(view != NULL && scoreLabel != NULL);
    view->pScore = scoreLabel;
    return view;
}// fin set_score_in_view()

GtkWidget *get_value_delay(ViewTetris *view){
    assert(view != NULL);
    return(view->valueDelay);
}// fin get_value_delay()

GtkWidget *get_score_in_view(ViewTetris *view){
    assert(view != NULL);
    return (view->pScore);
}// fin get_score_in_view()

ViewTetris *create_view_tetris(ModelTetris *model){
    assert(model != NULL);
    ViewTetris *view = malloc(sizeof(ViewTetris));
    if(view == NULL){
        return NULL;
    }
    view->model = model;
    
    
    return view;
}//fin create_view_tetris()

void destroy_view_tetris(ViewTetris *view){
    assert(view != NULL);

    free(view);
}//fin destroy_view_tetris()

ViewTetris *set_model(ViewTetris *view, ModelTetris *model){
    assert(view != NULL && model != NULL);

    view->model = model;

    return view;
}// fin set_model()

ViewTetris *set_drawingArea(ViewTetris *view, GtkWidget *drawingArea){
    assert(view != NULL && drawingArea != NULL);

    view->drawingArea = drawingArea;

    return view;
}// fin set_drawingArea()

GtkWidget *get_drawingArea(ViewTetris *view){
    assert(view != NULL);

    return view->drawingArea;
}// fin get_drawingArea()

void draw(GtkWidget *drawingArea, unsigned int x, unsigned int y){
    assert(x < 10 && y < 17);

    //int width = allocation.width - 5;
    int width = 355;
    int height = 595;
    int size_square = 36;
    //printf("Taille d'un carré : %d. Taille de la drawing area : %d x %d.\n", size_square, width, height);


    // Position réelle de la cellule sur la drawingArea
    int cell_real_x = x * size_square + 2;
    int cell_real_y = y * size_square + 2;
    cairo_t *cube = gdk_cairo_create(drawingArea->window);
    cairo_set_source_rgb(cube, 0.8, 0, 0);
    cairo_rectangle(cube, cell_real_x, cell_real_y, size_square, size_square);
    cairo_fill_preserve(cube);
    cairo_set_line_width(cube, 3);
    cairo_set_source_rgb(cube, 0.6, 0, 0);
    cairo_stroke(cube);
    cairo_destroy(cube);
    draw_horizontal_line(drawingArea);
}// fin draw()

void show_value_delay(ViewTetris *view, unsigned int n1){
    char str[100];
    sprintf(str, "Délai : %d\n", n1);
    gtk_label_set_text(GTK_LABEL(view->valueDelay), str);
}// fin show_value_delay()

void show_score(ViewTetris *view, unsigned int score){
    char str[50];
    sprintf(str, "Score : %d\n", score);
    gtk_label_set_text(GTK_LABEL(view->pScore), str);
}// fin show_score()

void draw_horizontal_line(GtkWidget *drawingArea) {
    cairo_t *cr = gdk_cairo_create(drawingArea->window);

    cairo_set_source_rgb(cr, 1.0, 0.0, 0.0); // couleur rouge
    cairo_set_line_width(cr, 3.0); // épaisseur de la ligne
    cairo_move_to(cr, 0, 74); // début de la ligne
    cairo_line_to(cr, 365, 74); // fin de la ligne
    cairo_stroke(cr); // dessiner la ligne

    cairo_destroy(cr);
}// fin draw_horizontal_line()
