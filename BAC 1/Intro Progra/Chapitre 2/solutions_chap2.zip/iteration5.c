/*
 * Chapitre 2: Structures de Contrôle
 * Itérations -- Exercice 5 (nombre de chiffres en base 10)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Juin 2021
 */

#include <stdio.h>

int main(){
  int nombre = 0, n;

  printf("Entrez une valeur pour n: ");
  scanf("%d", &n);

  /*
  * 4 questions:
  *  1. compteur et initialisation
  *     n (valeur introduite au clavier par l'utilisateur)
  *  2. nombre de tours de boucle
  *     pratiquement, il y aura log_10(n) tours de boucle.  Le logarithme en
  *     base 'b' donne le nombre de chiffres d'un nombre exprimé en base 'b'.
  *     Ainsi, le log_10(524526) ~ 5.71, ce qui donne bien 6 après arrondi.
  *  3. Gardien de Boucle
  *     utiliser le nombre de tours de boucle n'est pas très pertinent ici.
  *     A la place, on va "couper" le dernier chiffre du nombre n à chaque tour
  *     à l'aide d'une division entière.  La boucle s'arrête donc quand il n'y
  *     a plus de chiffres à isoler, soit quand n vaut 0.
  *     n > 0
  *  4. Corps de Boucle
  *     incrémenter le compteur de chiffre
  *     division n par 10.
  */
  while(n>0){
    nombre++;
    n /= 10;
  }//fin while

  printf("Nombre de chiffres en base 10 de %d: %d\n", n, nombre);
}//fin programme
