/*
 * Chapitre 2: Structures de Contrôle
 * Conditions -- Exercice 2 (positif/négatif, parité)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

int main(){
  int x;
  printf("Introduisez une valeur entière: ");
  scanf("%d", &x);

  if(x>=0)
    printf("la valeur entrée est positive\n");
  else
    printf("la valeur entrée est négative\n");

  if(x%2==0)
    printf("la valeur entrée est paire\n");
  else
    printf("la valeur entrée est impaire\n");
}//fin programme
