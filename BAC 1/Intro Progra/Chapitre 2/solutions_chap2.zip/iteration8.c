/*
 * Chapitre 2: Structures de Contrôle
 * Itérations -- Exercice 8 (approximation d'intégrale)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Juin 2021
 */

#include <stdio.h>
#include <math.h>

int main(){
  int a, b, N, i;
  float x, h, integrale=0.0;

  printf("Entrez les valeurs pour a et b: ");
  scanf("%d %d", &a, &b);

  printf("Entrez la valeur pour N: ");
  scanf("%d", &N);

  printf("Entrez la valeur pour x: ");
  scanf("%f", &x);

  h = (b-a)/N;

  /*
  * 4 questions:
  *  1. compteur et initialisation?
  *     i = 0
  *  2. nombre de tours de boulce?
  *     N
  *  3. gardien de boucle?
  *     i < N
  *  4. corps de boucle?
  *     somme cumulative de l'aire des rectangles pour la fonction cos()
  *     incrémenter le compteur de boucle i
  */
  for(i=0; i<N; i++)
    integrale += cos(a+(i*h));

  integrale *= h;

  printf("L'approximation de l'intégrale vaut %f\n", integrale);
}//fin programme
