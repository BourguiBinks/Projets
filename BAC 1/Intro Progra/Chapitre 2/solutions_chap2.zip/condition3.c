/*
 * Chapitre 2: Structures de Contrôle
 * Conditions -- Exercice 3 (affichage par ordre croissant)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Juin 2021
 */

#include <stdio.h>

int main(){
  double n1, n2, n3, tmp;

  printf("Entrez trois nombres réels : ");
  scanf("%lf %lf %lf", &n1, &n2, &n3);

  /*
   * L'idée de la solution est d'essayer de "trier" les 3 nombres et de les
   * permuter deux à deux si nécessaire de sorte que n1 contienne le plus petit,
   * n2 le nombre du "milieu" et n3 le plus grand.
   */

  if(n1 > n2){
    tmp = n2;
    n2 = n1;
    n1 = tmp;
  }

  if(n2 > n3){
    tmp = n3;
    n3 = n2;
    n2 = tmp;
  }

  if(n1 > n2){
    tmp = n2;
    n2 = n1;
    n1 = tmp;
  }

  printf("En ordre croissant : %lf, %lf et %lf\n", n1, n2, n3);

}//fin programme
