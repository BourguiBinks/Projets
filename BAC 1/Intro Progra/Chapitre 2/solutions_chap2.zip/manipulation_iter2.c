/*
 * Chapitre 2: Structures de Contrôle
 * Manipulation de Boucles -- Exercice 2 (bout de code)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Juin 2021
 */

#include <stdio.h>

int main(){
  int i;

  for(i=0; i<5; i++)
    printf("It's a long way to the top if you wanna Rock 'n' Roll!\n");
}//fin programme
