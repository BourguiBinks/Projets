/*
 * Chapitre 2: Structures de Contrôle
 * Itérations -- Exercice 3 (factorielle)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Juin 2019
 */

#include <stdio.h>

int main(){
  int f = 1, n;

  printf("Entrez une valeur pour n: ");
  scanf("%d", &n);

  /*
  * 4 étapes:
  *  1. compteur et initialisation
  *     n (valeur donnée par l'utilisateur)
  *  2. nombre de tours de boucle
  *     n-1
  *  3. Gardien de Boucle
  *     n > 0
  *  4. Corps de Boucle
  *     produit cumulatif pour les valeurs intermédiares de la factorielle
  *     décrémenter le compteur n
  */
  while(n > 0){
    f *= n;
    n--;
  }//fin while - n

  printf("%d! = %d\n", n, f);
}//fin programme
