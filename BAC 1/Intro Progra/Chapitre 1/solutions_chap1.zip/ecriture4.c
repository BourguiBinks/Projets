/*
 * Chapitre 1: Blocs, Variables, Instructions Simples
 * Ecriture de Code -- Exercice 4 (dizaines d'un nombre)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

int main(){
  int n, dizaine, centaine;

  printf("Entrez un nombre : ");
  scanf("%d", &n);

  dizaine = (n / 10) % 10;
  centaine = (n / 100) % 10;

  printf("Le chiffre des dizaines est %d\n", dizaine);
  printf("Le chiffre des centaines est %d\n", centaine);
}//fin programme
