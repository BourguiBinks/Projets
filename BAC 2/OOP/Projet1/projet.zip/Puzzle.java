// import java.lang.Object;
// import java.lang.String;
import java.util.Vector;

public class Puzzle{
    public final String initialConfiguration;
    private int cubeInGroup = 2;
    private Vector<Integer> groups = new Vector<>();
    private Cube[] cubes;

    public Puzzle(String initialConfiguration){
        this.initialConfiguration = initialConfiguration;
        this.cubes = new Cube[initialConfiguration.length()];
 
    }

    public void getAllGroups(String initialConfiguration){
        for(int i = 1; i < initialConfiguration.length() - 1; i++){
            if(initialConfiguration.charAt(i) == 'A'){
                groups.add(cubeInGroup);
                cubeInGroup = 2;
            }
            else
                cubeInGroup++;
                
            if(i == initialConfiguration.length() - 2)
                groups.add(cubeInGroup);
            // System.out.println("cubeInGroup :\n" + cubeInGroup);
        }

        // Affichage de tous les éléments du tableau groups
        for(int k = 0; k < groups.size(); k++)
            System.out.println("Group " + (k + 1) + ": " + groups.get(k));
            
    }

    
    public void fillCube(String initialConfiguration){
        // On initiantiate chaque groupe un par un
        
        int y = 0;
        int z = 0;
        for(int i = 0; i < groups.size(); i++){
            this.cubes[i] = new Cube(i,y,z,initialConfiguration.charAt(i));
            System.out.println("Cube : (" +  this.cubes[i].getX() + "," + this.cubes[i].getY() + "," + this.cubes[i].getZ() + "," + this.cubes[i].getGeometry() +")" );
        
        }
    }
}