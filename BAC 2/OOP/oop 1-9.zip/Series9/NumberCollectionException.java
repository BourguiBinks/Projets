public class NumberCollectionException extends Exception{
    public NumberCollectionException(){
        
    }
}