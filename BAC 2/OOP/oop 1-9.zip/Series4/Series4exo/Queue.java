public class Queue{
    private int size;
    private Node tail, head;

    public void put(int value){
        
    }

}