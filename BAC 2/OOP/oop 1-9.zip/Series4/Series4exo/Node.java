public class Node{
    private void element;
    private Node next;

    public Node(){
        this.element = null;
        this.next = null;
    }
    public Node(void element, Node next){
        this.element = element;
        this.next = next;
    }
    public Node(void element){
        this.element = element;
        this.next = null;
    }
    public void addElement(void element, Node node){
        
    }
}