/*
 * Object Oriented Programming 
 * Exercise Series 5
 */

public enum MyColor {
    RED, BLUE, GREEN
}