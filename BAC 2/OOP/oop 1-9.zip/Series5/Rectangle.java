public class Rectangle{
    private Coordinates min,max;
    public Rectangle(int xmin, int ymin, int xmax, int ymax){
        
    }
}